.. Yade documentation master file, created by
   sphinx-quickstart on Mon Nov 16 21:49:34 2009.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Yade Documentation
^^^^^^^^^^^^^^^^^^^^

.. toctree::
  :maxdepth: 2

  index-toctree-manuals.rst

  index-toctree-theory.rst

  index-toctree-reference.rst



