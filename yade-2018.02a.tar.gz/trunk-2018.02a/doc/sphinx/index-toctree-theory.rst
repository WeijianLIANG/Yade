
Theoretical background
========================

.. toctree::
  :maxdepth: 2
  
  formulation.rst
  publications.rst
