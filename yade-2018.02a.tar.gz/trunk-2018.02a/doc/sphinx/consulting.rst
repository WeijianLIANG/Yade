.. _consulting:

########################
Support and consulting
########################

We can provide technical support and training sessions on DEM modeling for researchers and engineers, as well as consulting services for specific problems.
Feel free to contact us by email at consult|A|yade-dem.org for any inquiry on such aspects.

Please use this contact for discussing paid support and/or consulting, exclusively. Basic questions on using Yade should follow the `regular way <https://yade-dem.org/wiki/Contact>`_ or will be disregarded. 