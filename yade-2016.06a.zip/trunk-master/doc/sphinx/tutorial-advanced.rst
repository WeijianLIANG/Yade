Advanced & more
===============

Particle size distribution
--------------------------

See :ref:`periodic-triaxial-test`

Clumps
------

:yref:`Clump`; see :ref:`periodic-triaxial-test`

Testing laws
------------

:yref:`LawTester`, :ysrc:`scripts/test/law-test.py`

New law
-------



Visualization
-------------

See the example :ref:`3d-postprocessing`

* :yref:`VTKRecorder` & `Paraview <http://www.paraview.org>`__
* :yref:`yade.qt.SnapshotEngine`


