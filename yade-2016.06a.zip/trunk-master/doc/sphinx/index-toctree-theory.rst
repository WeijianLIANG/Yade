
Theoretical background
========================

.. toctree::
  :maxdepth: 2
  
  formulation.rst
  fullPublications.rst
