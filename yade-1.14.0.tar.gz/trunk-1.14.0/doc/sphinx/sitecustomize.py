# necessary for our docstrings containing unicode characters
import sys
sys.setdefaultencoding('utf-8')
