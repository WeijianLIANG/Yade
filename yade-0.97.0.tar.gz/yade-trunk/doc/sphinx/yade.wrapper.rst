.. _yade.wrapper
Class reference (yade.wrapper module)
=======================================

.. toctree::
  :maxdepth: 2


.. currentmodule:: yade.wrapper
.. autosummary::

Bodies
----------------------------------------------------------------------------------------------------



Body
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. autoclass:: Body
	:members:
	:undoc-members:
	:inherited-members:



Shape
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. graphviz::

	digraph Shape {
		rankdir=RL;
		margin=.2;
		"Shape" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Shape"];
		"Box" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Box"];
		"Box" -> "Shape" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"Facet" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Facet"];
		"Facet" -> "Shape" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"Cylinder" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Cylinder"];
		"Cylinder" -> "Sphere" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"ChainedCylinder" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.ChainedCylinder"];
		"ChainedCylinder" -> "Cylinder" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"GridConnection" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.GridConnection"];
		"GridConnection" -> "Sphere" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"Sphere" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Sphere"];
		"Sphere" -> "Shape" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"Wall" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Wall"];
		"Wall" -> "Shape" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"Tetra" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Tetra"];
		"Tetra" -> "Shape" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"Clump" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Clump"];
		"Clump" -> "Shape" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"GridNode" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.GridNode"];
		"GridNode" -> "Sphere" [arrowsize=0.5,style="setlinewidth(0.5)"];
	}

.. autoclass:: Shape
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Box
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: ChainedCylinder
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Clump
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Cylinder
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Facet
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: GridConnection
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: GridNode
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Sphere
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Tetra
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Wall
	:members:
	:undoc-members:
	:inherited-members:



State
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. graphviz::

	digraph State {
		rankdir=RL;
		margin=.2;
		"State" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.State"];
		"JCFpmState" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.JCFpmState"];
		"JCFpmState" -> "State" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"ChainedState" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.ChainedState"];
		"ChainedState" -> "State" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"WireState" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.WireState"];
		"WireState" -> "State" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"CpmState" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.CpmState"];
		"CpmState" -> "State" [arrowsize=0.5,style="setlinewidth(0.5)"];
	}

.. autoclass:: State
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: ChainedState
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: CpmState
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: JCFpmState
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: WireState
	:members:
	:undoc-members:
	:inherited-members:



Material
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. graphviz::

	digraph Material {
		rankdir=RL;
		margin=.2;
		"Material" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Material"];
		"InelastCohFrictMat" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.InelastCohFrictMat"];
		"InelastCohFrictMat" -> "FrictMat" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"FrictMat" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.FrictMat"];
		"FrictMat" -> "ElastMat" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"LudingMat" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.LudingMat"];
		"LudingMat" -> "Material" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"BubbleMat" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.BubbleMat"];
		"BubbleMat" -> "Material" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"CpmMat" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.CpmMat"];
		"CpmMat" -> "FrictMat" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"WireMat" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.WireMat"];
		"WireMat" -> "FrictMat" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"CohFrictMat" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.CohFrictMat"];
		"CohFrictMat" -> "FrictMat" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"NormalInelasticMat" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.NormalInelasticMat"];
		"NormalInelasticMat" -> "FrictMat" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"ElastMat" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.ElastMat"];
		"ElastMat" -> "Material" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"JCFpmMat" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.JCFpmMat"];
		"JCFpmMat" -> "FrictMat" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"ViscElMat" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.ViscElMat"];
		"ViscElMat" -> "Material" [arrowsize=0.5,style="setlinewidth(0.5)"];
	}

.. autoclass:: Material
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: BubbleMat
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: CohFrictMat
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: CpmMat
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: ElastMat
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: FrictMat
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: InelastCohFrictMat
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: JCFpmMat
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: LudingMat
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: NormalInelasticMat
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: ViscElMat
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: WireMat
	:members:
	:undoc-members:
	:inherited-members:



Bound
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. graphviz::

	digraph Bound {
		rankdir=RL;
		margin=.2;
		"Bound" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Bound"];
		"Aabb" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Aabb"];
		"Aabb" -> "Bound" [arrowsize=0.5,style="setlinewidth(0.5)"];
	}

.. autoclass:: Bound
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Aabb
	:members:
	:undoc-members:
	:inherited-members:


Interactions
----------------------------------------------------------------------------------------------------



Interaction
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. autoclass:: Interaction
	:members:
	:undoc-members:
	:inherited-members:



IGeom
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. graphviz::

	digraph IGeom {
		rankdir=RL;
		margin=.2;
		"IGeom" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.IGeom"];
		"Dem3DofGeom" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Dem3DofGeom"];
		"Dem3DofGeom" -> "GenericSpheresContact" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"Dem3DofGeom_FacetSphere" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Dem3DofGeom_FacetSphere"];
		"Dem3DofGeom_FacetSphere" -> "Dem3DofGeom" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"ScGridCoGeom" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.ScGridCoGeom"];
		"ScGridCoGeom" -> "ScGeom6D" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"TTetraGeom" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.TTetraGeom"];
		"TTetraGeom" -> "IGeom" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"CylScGeom6D" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.CylScGeom6D"];
		"CylScGeom6D" -> "ScGeom6D" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"ScGeom6D" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.ScGeom6D"];
		"ScGeom6D" -> "ScGeom" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"Dem3DofGeom_WallSphere" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Dem3DofGeom_WallSphere"];
		"Dem3DofGeom_WallSphere" -> "Dem3DofGeom" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"GridNodeGeom6D" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.GridNodeGeom6D"];
		"GridNodeGeom6D" -> "ScGeom6D" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"CylScGeom" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.CylScGeom"];
		"CylScGeom" -> "ScGeom" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"L6Geom" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.L6Geom"];
		"L6Geom" -> "L3Geom" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"ChCylGeom6D" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.ChCylGeom6D"];
		"ChCylGeom6D" -> "ScGeom6D" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"ScGeom" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.ScGeom"];
		"ScGeom" -> "GenericSpheresContact" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"Dem3DofGeom_SphereSphere" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Dem3DofGeom_SphereSphere"];
		"Dem3DofGeom_SphereSphere" -> "Dem3DofGeom" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"GenericSpheresContact" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.GenericSpheresContact"];
		"GenericSpheresContact" -> "IGeom" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"GridCoGridCoGeom" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.GridCoGridCoGeom"];
		"GridCoGridCoGeom" -> "ScGeom" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"L3Geom" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.L3Geom"];
		"L3Geom" -> "GenericSpheresContact" [arrowsize=0.5,style="setlinewidth(0.5)"];
	}

.. autoclass:: IGeom
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: ChCylGeom6D
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: CylScGeom
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: CylScGeom6D
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Dem3DofGeom
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Dem3DofGeom_FacetSphere
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Dem3DofGeom_SphereSphere
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Dem3DofGeom_WallSphere
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: GenericSpheresContact
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: GridCoGridCoGeom
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: GridNodeGeom6D
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: L3Geom
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: L6Geom
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: ScGeom
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: ScGeom6D
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: ScGridCoGeom
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: TTetraGeom
	:members:
	:undoc-members:
	:inherited-members:



IPhys
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. graphviz::

	digraph IPhys {
		rankdir=RL;
		margin=.2;
		"IPhys" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.IPhys"];
		"MindlinCapillaryPhys" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.MindlinCapillaryPhys"];
		"MindlinCapillaryPhys" -> "MindlinPhys" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"InelastCohFrictPhys" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.InelastCohFrictPhys"];
		"InelastCohFrictPhys" -> "FrictPhys" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"FrictPhys" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.FrictPhys"];
		"FrictPhys" -> "NormShearPhys" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"ViscElPhys" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.ViscElPhys"];
		"ViscElPhys" -> "FrictPhys" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"LudingPhys" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.LudingPhys"];
		"LudingPhys" -> "FrictPhys" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"NormalInelasticityPhys" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.NormalInelasticityPhys"];
		"NormalInelasticityPhys" -> "FrictPhys" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"MindlinPhys" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.MindlinPhys"];
		"MindlinPhys" -> "FrictPhys" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"NormShearPhys" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.NormShearPhys"];
		"NormShearPhys" -> "NormPhys" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"CapillaryPhys" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.CapillaryPhys"];
		"CapillaryPhys" -> "FrictPhys" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"WirePhys" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.WirePhys"];
		"WirePhys" -> "FrictPhys" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"CohFrictPhys" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.CohFrictPhys"];
		"CohFrictPhys" -> "FrictPhys" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"CpmPhys" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.CpmPhys"];
		"CpmPhys" -> "NormShearPhys" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"ViscoFrictPhys" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.ViscoFrictPhys"];
		"ViscoFrictPhys" -> "FrictPhys" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"BubblePhys" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.BubblePhys"];
		"BubblePhys" -> "IPhys" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"NormPhys" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.NormPhys"];
		"NormPhys" -> "IPhys" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"JCFpmPhys" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.JCFpmPhys"];
		"JCFpmPhys" -> "NormShearPhys" [arrowsize=0.5,style="setlinewidth(0.5)"];
	}

.. autoclass:: IPhys
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: BubblePhys
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: CapillaryPhys
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: CohFrictPhys
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: CpmPhys
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: FrictPhys
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: InelastCohFrictPhys
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: JCFpmPhys
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: LudingPhys
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: MindlinCapillaryPhys
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: MindlinPhys
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: NormPhys
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: NormShearPhys
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: NormalInelasticityPhys
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: ViscElPhys
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: ViscoFrictPhys
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: WirePhys
	:members:
	:undoc-members:
	:inherited-members:


Global engines
----------------------------------------------------------------------------------------------------



GlobalEngine
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. graphviz::

	digraph GlobalEngine {
		rankdir=RL;
		margin=.2;
		"GlobalEngine" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.GlobalEngine"];
		"Collider" [shape="box",fontsize=8,style="setlinewidth(0.5),filled,dashed",fillcolor=grey,height=0.2,URL="yade.wrapper.html#yade.wrapper.Collider"];
		"Collider" -> "GlobalEngine" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"PeriodicEngine" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.PeriodicEngine"];
		"PeriodicEngine" -> "GlobalEngine" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"BoundaryController" [shape="box",fontsize=8,style="setlinewidth(0.5),filled,dashed",fillcolor=grey,height=0.2,URL="yade.wrapper.html#yade.wrapper.BoundaryController"];
		"BoundaryController" -> "GlobalEngine" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"CapillaryStressRecorder" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.CapillaryStressRecorder"];
		"CapillaryStressRecorder" -> "Recorder" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"Recorder" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Recorder"];
		"Recorder" -> "PeriodicEngine" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"ForceRecorder" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.ForceRecorder"];
		"ForceRecorder" -> "Recorder" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"DomainLimiter" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.DomainLimiter"];
		"DomainLimiter" -> "PeriodicEngine" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"GlobalStiffnessTimeStepper" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.GlobalStiffnessTimeStepper"];
		"GlobalStiffnessTimeStepper" -> "TimeStepper" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"FacetTopologyAnalyzer" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.FacetTopologyAnalyzer"];
		"FacetTopologyAnalyzer" -> "GlobalEngine" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"CpmStateUpdater" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.CpmStateUpdater"];
		"CpmStateUpdater" -> "PeriodicEngine" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"ResetRandomPosition" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.ResetRandomPosition"];
		"ResetRandomPosition" -> "PeriodicEngine" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"FieldApplier" [shape="box",fontsize=8,style="setlinewidth(0.5),filled,dashed",fillcolor=grey,height=0.2,URL="yade.wrapper.html#yade.wrapper.FieldApplier"];
		"FieldApplier" -> "GlobalEngine" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"BoxFactory" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.BoxFactory"];
		"BoxFactory" -> "SpheresFactory" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"CohesiveFrictionalContactLaw" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.CohesiveFrictionalContactLaw"];
		"CohesiveFrictionalContactLaw" -> "GlobalEngine" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"NewtonIntegrator" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.NewtonIntegrator"];
		"NewtonIntegrator" -> "GlobalEngine" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"TriaxialStateRecorder" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.TriaxialStateRecorder"];
		"TriaxialStateRecorder" -> "Recorder" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"Law2_ScGeom_CapillaryPhys_Capillarity" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Law2_ScGeom_CapillaryPhys_Capillarity"];
		"Law2_ScGeom_CapillaryPhys_Capillarity" -> "GlobalEngine" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"TorqueRecorder" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.TorqueRecorder"];
		"TorqueRecorder" -> "Recorder" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"TesselationWrapper" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.TesselationWrapper"];
		"TesselationWrapper" -> "GlobalEngine" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"ForceResetter" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.ForceResetter"];
		"ForceResetter" -> "GlobalEngine" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"TimeStepper" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.TimeStepper"];
		"TimeStepper" -> "GlobalEngine" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"TetraVolumetricLaw" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.TetraVolumetricLaw"];
		"TetraVolumetricLaw" -> "GlobalEngine" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"PyRunner" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.PyRunner"];
		"PyRunner" -> "PeriodicEngine" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"MicroMacroAnalyser" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.MicroMacroAnalyser"];
		"MicroMacroAnalyser" -> "GlobalEngine" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"CircularFactory" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.CircularFactory"];
		"CircularFactory" -> "SpheresFactory" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"SpheresFactory" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.SpheresFactory"];
		"SpheresFactory" -> "GlobalEngine" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"VTKRecorder" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.VTKRecorder"];
		"VTKRecorder" -> "PeriodicEngine" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"ElasticContactLaw" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.ElasticContactLaw"];
		"ElasticContactLaw" -> "GlobalEngine" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"SnapshotEngine" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.SnapshotEngine"];
		"SnapshotEngine" -> "PeriodicEngine" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"InteractionLoop" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.InteractionLoop"];
		"InteractionLoop" -> "GlobalEngine" [arrowsize=0.5,style="setlinewidth(0.5)"];
	}

.. autoclass:: GlobalEngine
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: BoxFactory
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: CapillaryStressRecorder
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: CircularFactory
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: CohesiveFrictionalContactLaw
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: CpmStateUpdater
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: DomainLimiter
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: ElasticContactLaw
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: FacetTopologyAnalyzer
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: ForceRecorder
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: ForceResetter
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: GlobalStiffnessTimeStepper
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: InteractionLoop
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Law2_ScGeom_CapillaryPhys_Capillarity
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: MicroMacroAnalyser
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: NewtonIntegrator
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: PeriodicEngine
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: PyRunner
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Recorder
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: ResetRandomPosition
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: SnapshotEngine
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: SpheresFactory
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: TesselationWrapper
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: TetraVolumetricLaw
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: TimeStepper
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: TorqueRecorder
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: TriaxialStateRecorder
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: VTKRecorder
	:members:
	:undoc-members:
	:inherited-members:



BoundaryController
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. graphviz::

	digraph BoundaryController {
		rankdir=RL;
		margin=.2;
		"BoundaryController" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.BoundaryController"];
		"Disp2DPropLoadEngine" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Disp2DPropLoadEngine"];
		"Disp2DPropLoadEngine" -> "BoundaryController" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"Peri3dController" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Peri3dController"];
		"Peri3dController" -> "BoundaryController" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"PeriIsoCompressor" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.PeriIsoCompressor"];
		"PeriIsoCompressor" -> "BoundaryController" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"KinemCTDEngine" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.KinemCTDEngine"];
		"KinemCTDEngine" -> "KinemSimpleShearBox" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"KinemCNSEngine" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.KinemCNSEngine"];
		"KinemCNSEngine" -> "KinemSimpleShearBox" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"TriaxialCompressionEngine" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.TriaxialCompressionEngine"];
		"TriaxialCompressionEngine" -> "TriaxialStressController" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"KinemCNLEngine" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.KinemCNLEngine"];
		"KinemCNLEngine" -> "KinemSimpleShearBox" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"UniaxialStrainer" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.UniaxialStrainer"];
		"UniaxialStrainer" -> "BoundaryController" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"ThreeDTriaxialEngine" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.ThreeDTriaxialEngine"];
		"ThreeDTriaxialEngine" -> "TriaxialStressController" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"PeriTriaxController" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.PeriTriaxController"];
		"PeriTriaxController" -> "BoundaryController" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"TriaxialStressController" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.TriaxialStressController"];
		"TriaxialStressController" -> "BoundaryController" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"KinemCNDEngine" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.KinemCNDEngine"];
		"KinemCNDEngine" -> "KinemSimpleShearBox" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"KinemSimpleShearBox" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.KinemSimpleShearBox"];
		"KinemSimpleShearBox" -> "BoundaryController" [arrowsize=0.5,style="setlinewidth(0.5)"];
	}

.. autoclass:: BoundaryController
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Disp2DPropLoadEngine
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: KinemCNDEngine
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: KinemCNLEngine
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: KinemCNSEngine
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: KinemCTDEngine
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: KinemSimpleShearBox
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Peri3dController
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: PeriIsoCompressor
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: PeriTriaxController
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: ThreeDTriaxialEngine
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: TriaxialCompressionEngine
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: TriaxialStressController
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: UniaxialStrainer
	:members:
	:undoc-members:
	:inherited-members:



Collider
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. graphviz::

	digraph Collider {
		rankdir=RL;
		margin=.2;
		"Collider" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Collider"];
		"SpatialQuickSortCollider" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.SpatialQuickSortCollider"];
		"SpatialQuickSortCollider" -> "Collider" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"PersistentTriangulationCollider" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.PersistentTriangulationCollider"];
		"PersistentTriangulationCollider" -> "Collider" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"FlatGridCollider" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.FlatGridCollider"];
		"FlatGridCollider" -> "Collider" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"InsertionSortCollider" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.InsertionSortCollider"];
		"InsertionSortCollider" -> "Collider" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"ZECollider" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.ZECollider"];
		"ZECollider" -> "Collider" [arrowsize=0.5,style="setlinewidth(0.5)"];
	}

.. autoclass:: Collider
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: FlatGridCollider
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: InsertionSortCollider
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: PersistentTriangulationCollider
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: SpatialQuickSortCollider
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: ZECollider
	:members:
	:undoc-members:
	:inherited-members:



FieldApplier
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. graphviz::

	digraph FieldApplier {
		rankdir=RL;
		margin=.2;
		"FieldApplier" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.FieldApplier"];
		"CentralGravityEngine" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.CentralGravityEngine"];
		"CentralGravityEngine" -> "FieldApplier" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"AxialGravityEngine" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.AxialGravityEngine"];
		"AxialGravityEngine" -> "FieldApplier" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"HdapsGravityEngine" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.HdapsGravityEngine"];
		"HdapsGravityEngine" -> "GravityEngine" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"GravityEngine" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.GravityEngine"];
		"GravityEngine" -> "FieldApplier" [arrowsize=0.5,style="setlinewidth(0.5)"];
	}

.. autoclass:: FieldApplier
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: AxialGravityEngine
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: CentralGravityEngine
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: GravityEngine
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: HdapsGravityEngine
	:members:
	:undoc-members:
	:inherited-members:


Partial engines
----------------------------------------------------------------------------------------------------



.. graphviz::

	digraph PartialEngine {
		rankdir=RL;
		margin=.2;
		"PartialEngine" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.PartialEngine"];
		"ServoPIDController" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.ServoPIDController"];
		"ServoPIDController" -> "TranslationEngine" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"CombinedKinematicEngine" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.CombinedKinematicEngine"];
		"CombinedKinematicEngine" -> "PartialEngine" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"DragEngine" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.DragEngine"];
		"DragEngine" -> "PartialEngine" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"HarmonicRotationEngine" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.HarmonicRotationEngine"];
		"HarmonicRotationEngine" -> "RotationEngine" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"RadialForceEngine" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.RadialForceEngine"];
		"RadialForceEngine" -> "PartialEngine" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"InterpolatingHelixEngine" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.InterpolatingHelixEngine"];
		"InterpolatingHelixEngine" -> "HelixEngine" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"RotationEngine" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.RotationEngine"];
		"RotationEngine" -> "KinematicEngine" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"HarmonicMotionEngine" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.HarmonicMotionEngine"];
		"HarmonicMotionEngine" -> "KinematicEngine" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"LawTester" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.LawTester"];
		"LawTester" -> "PartialEngine" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"LinearDragEngine" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.LinearDragEngine"];
		"LinearDragEngine" -> "PartialEngine" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"ForceEngine" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.ForceEngine"];
		"ForceEngine" -> "PartialEngine" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"TranslationEngine" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.TranslationEngine"];
		"TranslationEngine" -> "KinematicEngine" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"StepDisplacer" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.StepDisplacer"];
		"StepDisplacer" -> "PartialEngine" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"TorqueEngine" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.TorqueEngine"];
		"TorqueEngine" -> "PartialEngine" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"InterpolatingDirectedForceEngine" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.InterpolatingDirectedForceEngine"];
		"InterpolatingDirectedForceEngine" -> "ForceEngine" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"HelixEngine" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.HelixEngine"];
		"HelixEngine" -> "RotationEngine" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"KinematicEngine" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.KinematicEngine"];
		"KinematicEngine" -> "PartialEngine" [arrowsize=0.5,style="setlinewidth(0.5)"];
	}

.. autoclass:: PartialEngine
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: CombinedKinematicEngine
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: DragEngine
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: ForceEngine
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: HarmonicMotionEngine
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: HarmonicRotationEngine
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: HelixEngine
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: InterpolatingDirectedForceEngine
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: InterpolatingHelixEngine
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: KinematicEngine
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: LawTester
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: LinearDragEngine
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: RadialForceEngine
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: RotationEngine
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: ServoPIDController
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: StepDisplacer
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: TorqueEngine
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: TranslationEngine
	:members:
	:undoc-members:
	:inherited-members:


Bounding volume creation
----------------------------------------------------------------------------------------------------



BoundFunctor
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. graphviz::

	digraph BoundFunctor {
		rankdir=RL;
		margin=.2;
		"BoundFunctor" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.BoundFunctor"];
		"Bo1_ChainedCylinder_Aabb" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Bo1_ChainedCylinder_Aabb"];
		"Bo1_ChainedCylinder_Aabb" -> "BoundFunctor" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"Bo1_Sphere_Aabb" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Bo1_Sphere_Aabb"];
		"Bo1_Sphere_Aabb" -> "BoundFunctor" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"Bo1_Box_Aabb" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Bo1_Box_Aabb"];
		"Bo1_Box_Aabb" -> "BoundFunctor" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"Bo1_Facet_Aabb" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Bo1_Facet_Aabb"];
		"Bo1_Facet_Aabb" -> "BoundFunctor" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"Bo1_GridConnection_Aabb" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Bo1_GridConnection_Aabb"];
		"Bo1_GridConnection_Aabb" -> "BoundFunctor" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"Bo1_Tetra_Aabb" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Bo1_Tetra_Aabb"];
		"Bo1_Tetra_Aabb" -> "BoundFunctor" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"Bo1_Wall_Aabb" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Bo1_Wall_Aabb"];
		"Bo1_Wall_Aabb" -> "BoundFunctor" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"Bo1_Cylinder_Aabb" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Bo1_Cylinder_Aabb"];
		"Bo1_Cylinder_Aabb" -> "BoundFunctor" [arrowsize=0.5,style="setlinewidth(0.5)"];
	}

.. autoclass:: BoundFunctor
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Bo1_Box_Aabb
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Bo1_ChainedCylinder_Aabb
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Bo1_Cylinder_Aabb
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Bo1_Facet_Aabb
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Bo1_GridConnection_Aabb
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Bo1_Sphere_Aabb
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Bo1_Tetra_Aabb
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Bo1_Wall_Aabb
	:members:
	:undoc-members:
	:inherited-members:



BoundDispatcher
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. autoclass:: BoundDispatcher
	:members:
	:undoc-members:
	:inherited-members:


Interaction Geometry creation
----------------------------------------------------------------------------------------------------



IGeomFunctor
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. graphviz::

	digraph IGeomFunctor {
		rankdir=RL;
		margin=.2;
		"IGeomFunctor" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.IGeomFunctor"];
		"Ig2_Sphere_Sphere_Dem3DofGeom" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Ig2_Sphere_Sphere_Dem3DofGeom"];
		"Ig2_Sphere_Sphere_Dem3DofGeom" -> "IGeomFunctor" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"Ig2_Box_Sphere_ScGeom6D" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Ig2_Box_Sphere_ScGeom6D"];
		"Ig2_Box_Sphere_ScGeom6D" -> "Ig2_Box_Sphere_ScGeom" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"Ig2_ChainedCylinder_ChainedCylinder_ScGeom6D" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Ig2_ChainedCylinder_ChainedCylinder_ScGeom6D"];
		"Ig2_ChainedCylinder_ChainedCylinder_ScGeom6D" -> "IGeomFunctor" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"Ig2_Wall_Sphere_ScGeom" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Ig2_Wall_Sphere_ScGeom"];
		"Ig2_Wall_Sphere_ScGeom" -> "IGeomFunctor" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"Ig2_Sphere_Sphere_L6Geom" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Ig2_Sphere_Sphere_L6Geom"];
		"Ig2_Sphere_Sphere_L6Geom" -> "Ig2_Sphere_Sphere_L3Geom" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"Ig2_Facet_Sphere_ScGeom6D" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Ig2_Facet_Sphere_ScGeom6D"];
		"Ig2_Facet_Sphere_ScGeom6D" -> "Ig2_Facet_Sphere_ScGeom" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"Ig2_Sphere_Sphere_ScGeom6D" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Ig2_Sphere_Sphere_ScGeom6D"];
		"Ig2_Sphere_Sphere_ScGeom6D" -> "Ig2_Sphere_Sphere_ScGeom" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"Ig2_Sphere_GridConnection_ScGridCoGeom" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Ig2_Sphere_GridConnection_ScGridCoGeom"];
		"Ig2_Sphere_GridConnection_ScGridCoGeom" -> "IGeomFunctor" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"Ig2_Facet_Sphere_Dem3DofGeom" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Ig2_Facet_Sphere_Dem3DofGeom"];
		"Ig2_Facet_Sphere_Dem3DofGeom" -> "IGeomFunctor" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"Ig2_Facet_Sphere_ScGeom" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Ig2_Facet_Sphere_ScGeom"];
		"Ig2_Facet_Sphere_ScGeom" -> "IGeomFunctor" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"Ig2_Sphere_ChainedCylinder_CylScGeom" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Ig2_Sphere_ChainedCylinder_CylScGeom"];
		"Ig2_Sphere_ChainedCylinder_CylScGeom" -> "IGeomFunctor" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"Ig2_Wall_Sphere_L3Geom" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Ig2_Wall_Sphere_L3Geom"];
		"Ig2_Wall_Sphere_L3Geom" -> "Ig2_Sphere_Sphere_L3Geom" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"Ig2_Facet_Sphere_L3Geom" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Ig2_Facet_Sphere_L3Geom"];
		"Ig2_Facet_Sphere_L3Geom" -> "Ig2_Sphere_Sphere_L3Geom" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"Ig2_Sphere_Sphere_L3Geom" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Ig2_Sphere_Sphere_L3Geom"];
		"Ig2_Sphere_Sphere_L3Geom" -> "IGeomFunctor" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"Ig2_Box_Sphere_ScGeom" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Ig2_Box_Sphere_ScGeom"];
		"Ig2_Box_Sphere_ScGeom" -> "IGeomFunctor" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"Ig2_Tetra_Tetra_TTetraGeom" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Ig2_Tetra_Tetra_TTetraGeom"];
		"Ig2_Tetra_Tetra_TTetraGeom" -> "IGeomFunctor" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"Ig2_GridNode_GridNode_GridNodeGeom6D" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Ig2_GridNode_GridNode_GridNodeGeom6D"];
		"Ig2_GridNode_GridNode_GridNodeGeom6D" -> "Ig2_Sphere_Sphere_ScGeom" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"Ig2_Sphere_Sphere_ScGeom" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Ig2_Sphere_Sphere_ScGeom"];
		"Ig2_Sphere_Sphere_ScGeom" -> "IGeomFunctor" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"Ig2_GridConnection_GridConnection_GridCoGridCoGeom" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Ig2_GridConnection_GridConnection_GridCoGridCoGeom"];
		"Ig2_GridConnection_GridConnection_GridCoGridCoGeom" -> "IGeomFunctor" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"Ig2_Sphere_ChainedCylinder_CylScGeom6D" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Ig2_Sphere_ChainedCylinder_CylScGeom6D"];
		"Ig2_Sphere_ChainedCylinder_CylScGeom6D" -> "Ig2_Sphere_ChainedCylinder_CylScGeom" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"Ig2_Wall_Sphere_Dem3DofGeom" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Ig2_Wall_Sphere_Dem3DofGeom"];
		"Ig2_Wall_Sphere_Dem3DofGeom" -> "IGeomFunctor" [arrowsize=0.5,style="setlinewidth(0.5)"];
	}

.. autoclass:: IGeomFunctor
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Ig2_Box_Sphere_ScGeom
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Ig2_Box_Sphere_ScGeom6D
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Ig2_ChainedCylinder_ChainedCylinder_ScGeom6D
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Ig2_Facet_Sphere_Dem3DofGeom
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Ig2_Facet_Sphere_L3Geom
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Ig2_Facet_Sphere_ScGeom
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Ig2_Facet_Sphere_ScGeom6D
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Ig2_GridConnection_GridConnection_GridCoGridCoGeom
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Ig2_GridNode_GridNode_GridNodeGeom6D
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Ig2_Sphere_ChainedCylinder_CylScGeom
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Ig2_Sphere_ChainedCylinder_CylScGeom6D
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Ig2_Sphere_GridConnection_ScGridCoGeom
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Ig2_Sphere_Sphere_Dem3DofGeom
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Ig2_Sphere_Sphere_L3Geom
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Ig2_Sphere_Sphere_L6Geom
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Ig2_Sphere_Sphere_ScGeom
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Ig2_Sphere_Sphere_ScGeom6D
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Ig2_Tetra_Tetra_TTetraGeom
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Ig2_Wall_Sphere_Dem3DofGeom
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Ig2_Wall_Sphere_L3Geom
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Ig2_Wall_Sphere_ScGeom
	:members:
	:undoc-members:
	:inherited-members:



IGeomDispatcher
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. autoclass:: IGeomDispatcher
	:members:
	:undoc-members:
	:inherited-members:


Interaction Physics creation
----------------------------------------------------------------------------------------------------



IPhysFunctor
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. graphviz::

	digraph IPhysFunctor {
		rankdir=RL;
		margin=.2;
		"IPhysFunctor" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.IPhysFunctor"];
		"Ip2_FrictMat_FrictMat_CapillaryPhys" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Ip2_FrictMat_FrictMat_CapillaryPhys"];
		"Ip2_FrictMat_FrictMat_CapillaryPhys" -> "IPhysFunctor" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"Ip2_FrictMat_FrictMat_FrictPhys" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Ip2_FrictMat_FrictMat_FrictPhys"];
		"Ip2_FrictMat_FrictMat_FrictPhys" -> "IPhysFunctor" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"Ip2_LudingMat_LudingMat_LudingPhys" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Ip2_LudingMat_LudingMat_LudingPhys"];
		"Ip2_LudingMat_LudingMat_LudingPhys" -> "IPhysFunctor" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"Ip2_2xInelastCohFrictMat_InelastCohFrictPhys" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Ip2_2xInelastCohFrictMat_InelastCohFrictPhys"];
		"Ip2_2xInelastCohFrictMat_InelastCohFrictPhys" -> "IPhysFunctor" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"Ip2_FrictMat_FrictMat_ViscoFrictPhys" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Ip2_FrictMat_FrictMat_ViscoFrictPhys"];
		"Ip2_FrictMat_FrictMat_ViscoFrictPhys" -> "Ip2_FrictMat_FrictMat_FrictPhys" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"Ip2_FrictMat_FrictMat_MindlinCapillaryPhys" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Ip2_FrictMat_FrictMat_MindlinCapillaryPhys"];
		"Ip2_FrictMat_FrictMat_MindlinCapillaryPhys" -> "IPhysFunctor" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"Ip2_FrictMat_CpmMat_FrictPhys" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Ip2_FrictMat_CpmMat_FrictPhys"];
		"Ip2_FrictMat_CpmMat_FrictPhys" -> "IPhysFunctor" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"Ip2_FrictMat_FrictMat_MindlinPhys" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Ip2_FrictMat_FrictMat_MindlinPhys"];
		"Ip2_FrictMat_FrictMat_MindlinPhys" -> "IPhysFunctor" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"Ip2_WireMat_WireMat_WirePhys" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Ip2_WireMat_WireMat_WirePhys"];
		"Ip2_WireMat_WireMat_WirePhys" -> "IPhysFunctor" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"Ip2_CpmMat_CpmMat_CpmPhys" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Ip2_CpmMat_CpmMat_CpmPhys"];
		"Ip2_CpmMat_CpmMat_CpmPhys" -> "IPhysFunctor" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"Ip2_2xNormalInelasticMat_NormalInelasticityPhys" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Ip2_2xNormalInelasticMat_NormalInelasticityPhys"];
		"Ip2_2xNormalInelasticMat_NormalInelasticityPhys" -> "IPhysFunctor" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"Ip2_CohFrictMat_CohFrictMat_CohFrictPhys" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Ip2_CohFrictMat_CohFrictMat_CohFrictPhys"];
		"Ip2_CohFrictMat_CohFrictMat_CohFrictPhys" -> "IPhysFunctor" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"Ip2_BubbleMat_BubbleMat_BubblePhys" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Ip2_BubbleMat_BubbleMat_BubblePhys"];
		"Ip2_BubbleMat_BubbleMat_BubblePhys" -> "IPhysFunctor" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"Ip2_JCFpmMat_JCFpmMat_JCFpmPhys" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Ip2_JCFpmMat_JCFpmMat_JCFpmPhys"];
		"Ip2_JCFpmMat_JCFpmMat_JCFpmPhys" -> "IPhysFunctor" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"Ip2_ViscElMat_ViscElMat_ViscElPhys" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Ip2_ViscElMat_ViscElMat_ViscElPhys"];
		"Ip2_ViscElMat_ViscElMat_ViscElPhys" -> "IPhysFunctor" [arrowsize=0.5,style="setlinewidth(0.5)"];
	}

.. autoclass:: IPhysFunctor
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Ip2_2xInelastCohFrictMat_InelastCohFrictPhys
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Ip2_2xNormalInelasticMat_NormalInelasticityPhys
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Ip2_BubbleMat_BubbleMat_BubblePhys
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Ip2_CohFrictMat_CohFrictMat_CohFrictPhys
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Ip2_CpmMat_CpmMat_CpmPhys
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Ip2_FrictMat_CpmMat_FrictPhys
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Ip2_FrictMat_FrictMat_CapillaryPhys
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Ip2_FrictMat_FrictMat_FrictPhys
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Ip2_FrictMat_FrictMat_MindlinCapillaryPhys
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Ip2_FrictMat_FrictMat_MindlinPhys
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Ip2_FrictMat_FrictMat_ViscoFrictPhys
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Ip2_JCFpmMat_JCFpmMat_JCFpmPhys
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Ip2_LudingMat_LudingMat_LudingPhys
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Ip2_ViscElMat_ViscElMat_ViscElPhys
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Ip2_WireMat_WireMat_WirePhys
	:members:
	:undoc-members:
	:inherited-members:



IPhysDispatcher
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. autoclass:: IPhysDispatcher
	:members:
	:undoc-members:
	:inherited-members:


Constitutive laws
----------------------------------------------------------------------------------------------------



LawFunctor
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. graphviz::

	digraph LawFunctor {
		rankdir=RL;
		margin=.2;
		"LawFunctor" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.LawFunctor"];
		"Law2_ScGeom_BubblePhys_Bubble" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Law2_ScGeom_BubblePhys_Bubble"];
		"Law2_ScGeom_BubblePhys_Bubble" -> "LawFunctor" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"Law2_ScGeom_CpmPhys_Cpm" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Law2_ScGeom_CpmPhys_Cpm"];
		"Law2_ScGeom_CpmPhys_Cpm" -> "LawFunctor" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"Law2_ChCylGeom6D_CohFrictPhys_CohesionMoment" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Law2_ChCylGeom6D_CohFrictPhys_CohesionMoment"];
		"Law2_ChCylGeom6D_CohFrictPhys_CohesionMoment" -> "LawFunctor" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"Law2_CylScGeom_FrictPhys_CundallStrack" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Law2_CylScGeom_FrictPhys_CundallStrack"];
		"Law2_CylScGeom_FrictPhys_CundallStrack" -> "LawFunctor" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"Law2_ScGeom_MindlinPhys_HertzWithLinearShear" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Law2_ScGeom_MindlinPhys_HertzWithLinearShear"];
		"Law2_ScGeom_MindlinPhys_HertzWithLinearShear" -> "LawFunctor" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"Law2_ScGeom6D_NormalInelasticityPhys_NormalInelasticity" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Law2_ScGeom6D_NormalInelasticityPhys_NormalInelasticity"];
		"Law2_ScGeom6D_NormalInelasticityPhys_NormalInelasticity" -> "LawFunctor" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"Law2_CylScGeom6D_CohFrictPhys_CohesionMoment" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Law2_CylScGeom6D_CohFrictPhys_CohesionMoment"];
		"Law2_CylScGeom6D_CohFrictPhys_CohesionMoment" -> "LawFunctor" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"Law2_L6Geom_FrictPhys_Linear" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Law2_L6Geom_FrictPhys_Linear"];
		"Law2_L6Geom_FrictPhys_Linear" -> "Law2_L3Geom_FrictPhys_ElPerfPl" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"Law2_ScGeom_FrictPhys_CundallStrack" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Law2_ScGeom_FrictPhys_CundallStrack"];
		"Law2_ScGeom_FrictPhys_CundallStrack" -> "LawFunctor" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"Law2_ScGeom_WirePhys_WirePM" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Law2_ScGeom_WirePhys_WirePM"];
		"Law2_ScGeom_WirePhys_WirePM" -> "LawFunctor" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"Law2_ScGeom6D_InelastCohFrictPhys_CohesionMoment" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Law2_ScGeom6D_InelastCohFrictPhys_CohesionMoment"];
		"Law2_ScGeom6D_InelastCohFrictPhys_CohesionMoment" -> "LawFunctor" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"Law2_ScGeom6D_CohFrictPhys_CohesionMoment" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Law2_ScGeom6D_CohFrictPhys_CohesionMoment"];
		"Law2_ScGeom6D_CohFrictPhys_CohesionMoment" -> "LawFunctor" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"Law2_L3Geom_FrictPhys_ElPerfPl" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Law2_L3Geom_FrictPhys_ElPerfPl"];
		"Law2_L3Geom_FrictPhys_ElPerfPl" -> "LawFunctor" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"Law2_ScGeom_ViscElPhys_Basic" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Law2_ScGeom_ViscElPhys_Basic"];
		"Law2_ScGeom_ViscElPhys_Basic" -> "LawFunctor" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"Law2_ScGridCoGeom_CohFrictPhys_CundallStrack" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Law2_ScGridCoGeom_CohFrictPhys_CundallStrack"];
		"Law2_ScGridCoGeom_CohFrictPhys_CundallStrack" -> "LawFunctor" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"Law2_ScGeom_MindlinPhys_Mindlin" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Law2_ScGeom_MindlinPhys_Mindlin"];
		"Law2_ScGeom_MindlinPhys_Mindlin" -> "LawFunctor" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"Law2_ScGeom_LudingPhys_Basic" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Law2_ScGeom_LudingPhys_Basic"];
		"Law2_ScGeom_LudingPhys_Basic" -> "LawFunctor" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"Law2_ScGeom_MindlinPhys_MindlinDeresiewitz" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Law2_ScGeom_MindlinPhys_MindlinDeresiewitz"];
		"Law2_ScGeom_MindlinPhys_MindlinDeresiewitz" -> "LawFunctor" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"Law2_ScGridCoGeom_FrictPhys_CundallStrack" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Law2_ScGridCoGeom_FrictPhys_CundallStrack"];
		"Law2_ScGridCoGeom_FrictPhys_CundallStrack" -> "LawFunctor" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"Law2_ScGeom_ViscoFrictPhys_CundallStrack" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Law2_ScGeom_ViscoFrictPhys_CundallStrack"];
		"Law2_ScGeom_ViscoFrictPhys_CundallStrack" -> "Law2_ScGeom_FrictPhys_CundallStrack" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"Law2_ScGeom_JCFpmPhys_JointedCohesiveFrictionalPM" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Law2_ScGeom_JCFpmPhys_JointedCohesiveFrictionalPM"];
		"Law2_ScGeom_JCFpmPhys_JointedCohesiveFrictionalPM" -> "LawFunctor" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"Law2_GridCoGridCoGeom_FrictPhys_CundallStrack" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Law2_GridCoGridCoGeom_FrictPhys_CundallStrack"];
		"Law2_GridCoGridCoGeom_FrictPhys_CundallStrack" -> "Law2_ScGeom_FrictPhys_CundallStrack" [arrowsize=0.5,style="setlinewidth(0.5)"];
	}

.. autoclass:: LawFunctor
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Law2_ChCylGeom6D_CohFrictPhys_CohesionMoment
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Law2_CylScGeom6D_CohFrictPhys_CohesionMoment
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Law2_CylScGeom_FrictPhys_CundallStrack
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Law2_GridCoGridCoGeom_FrictPhys_CundallStrack
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Law2_L3Geom_FrictPhys_ElPerfPl
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Law2_L6Geom_FrictPhys_Linear
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Law2_ScGeom6D_CohFrictPhys_CohesionMoment
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Law2_ScGeom6D_InelastCohFrictPhys_CohesionMoment
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Law2_ScGeom6D_NormalInelasticityPhys_NormalInelasticity
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Law2_ScGeom_BubblePhys_Bubble
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Law2_ScGeom_CpmPhys_Cpm
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Law2_ScGeom_FrictPhys_CundallStrack
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Law2_ScGeom_JCFpmPhys_JointedCohesiveFrictionalPM
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Law2_ScGeom_LudingPhys_Basic
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Law2_ScGeom_MindlinPhys_HertzWithLinearShear
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Law2_ScGeom_MindlinPhys_Mindlin
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Law2_ScGeom_MindlinPhys_MindlinDeresiewitz
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Law2_ScGeom_ViscElPhys_Basic
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Law2_ScGeom_ViscoFrictPhys_CundallStrack
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Law2_ScGeom_WirePhys_WirePM
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Law2_ScGridCoGeom_CohFrictPhys_CundallStrack
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Law2_ScGridCoGeom_FrictPhys_CundallStrack
	:members:
	:undoc-members:
	:inherited-members:



LawDispatcher
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. autoclass:: LawDispatcher
	:members:
	:undoc-members:
	:inherited-members:


Callbacks
----------------------------------------------------------------------------------------------------



.. graphviz::

	digraph IntrCallback {
		rankdir=RL;
		margin=.2;
		"IntrCallback" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.IntrCallback"];
		"SumIntrForcesCb" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.SumIntrForcesCb"];
		"SumIntrForcesCb" -> "IntrCallback" [arrowsize=0.5,style="setlinewidth(0.5)"];
	}

.. autoclass:: IntrCallback
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: SumIntrForcesCb
	:members:
	:undoc-members:
	:inherited-members:


Preprocessors
----------------------------------------------------------------------------------------------------



.. graphviz::

	digraph FileGenerator {
		rankdir=RL;
		margin=.2;
		"FileGenerator" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.FileGenerator"];
		"CapillaryTriaxialTest" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.CapillaryTriaxialTest"];
		"CapillaryTriaxialTest" -> "FileGenerator" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"CohesiveTriaxialTest" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.CohesiveTriaxialTest"];
		"CohesiveTriaxialTest" -> "FileGenerator" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"SimpleShear" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.SimpleShear"];
		"SimpleShear" -> "FileGenerator" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"TriaxialTest" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.TriaxialTest"];
		"TriaxialTest" -> "FileGenerator" [arrowsize=0.5,style="setlinewidth(0.5)"];
	}

.. autoclass:: FileGenerator
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: CapillaryTriaxialTest
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: CohesiveTriaxialTest
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: SimpleShear
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: TriaxialTest
	:members:
	:undoc-members:
	:inherited-members:


Rendering
----------------------------------------------------------------------------------------------------



OpenGLRenderer
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. autoclass:: OpenGLRenderer
	:members:
	:undoc-members:
	:inherited-members:



GlShapeFunctor
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. graphviz::

	digraph GlShapeFunctor {
		rankdir=RL;
		margin=.2;
		"GlShapeFunctor" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.GlShapeFunctor"];
		"Gl1_Sphere" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Gl1_Sphere"];
		"Gl1_Sphere" -> "GlShapeFunctor" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"Gl1_Tetra" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Gl1_Tetra"];
		"Gl1_Tetra" -> "GlShapeFunctor" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"Gl1_Wall" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Gl1_Wall"];
		"Gl1_Wall" -> "GlShapeFunctor" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"Gl1_GridConnection" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Gl1_GridConnection"];
		"Gl1_GridConnection" -> "GlShapeFunctor" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"Gl1_Box" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Gl1_Box"];
		"Gl1_Box" -> "GlShapeFunctor" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"Gl1_ChainedCylinder" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Gl1_ChainedCylinder"];
		"Gl1_ChainedCylinder" -> "Gl1_Cylinder" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"Gl1_Cylinder" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Gl1_Cylinder"];
		"Gl1_Cylinder" -> "GlShapeFunctor" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"Gl1_Facet" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Gl1_Facet"];
		"Gl1_Facet" -> "GlShapeFunctor" [arrowsize=0.5,style="setlinewidth(0.5)"];
	}

.. autoclass:: GlShapeFunctor
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Gl1_Box
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Gl1_ChainedCylinder
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Gl1_Cylinder
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Gl1_Facet
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Gl1_GridConnection
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Gl1_Sphere
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Gl1_Tetra
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Gl1_Wall
	:members:
	:undoc-members:
	:inherited-members:



GlStateFunctor
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. autoclass:: GlStateFunctor
	:members:
	:undoc-members:
	:inherited-members:



GlBoundFunctor
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. graphviz::

	digraph GlBoundFunctor {
		rankdir=RL;
		margin=.2;
		"GlBoundFunctor" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.GlBoundFunctor"];
		"Gl1_Aabb" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Gl1_Aabb"];
		"Gl1_Aabb" -> "GlBoundFunctor" [arrowsize=0.5,style="setlinewidth(0.5)"];
	}

.. autoclass:: GlBoundFunctor
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Gl1_Aabb
	:members:
	:undoc-members:
	:inherited-members:



GlIGeomFunctor
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. graphviz::

	digraph GlIGeomFunctor {
		rankdir=RL;
		margin=.2;
		"GlIGeomFunctor" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.GlIGeomFunctor"];
		"Gl1_L6Geom" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Gl1_L6Geom"];
		"Gl1_L6Geom" -> "Gl1_L3Geom" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"Gl1_Dem3DofGeom_SphereSphere" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Gl1_Dem3DofGeom_SphereSphere"];
		"Gl1_Dem3DofGeom_SphereSphere" -> "GlIGeomFunctor" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"Gl1_Dem3DofGeom_FacetSphere" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Gl1_Dem3DofGeom_FacetSphere"];
		"Gl1_Dem3DofGeom_FacetSphere" -> "GlIGeomFunctor" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"Gl1_L3Geom" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Gl1_L3Geom"];
		"Gl1_L3Geom" -> "GlIGeomFunctor" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"Gl1_Dem3DofGeom_WallSphere" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Gl1_Dem3DofGeom_WallSphere"];
		"Gl1_Dem3DofGeom_WallSphere" -> "GlIGeomFunctor" [arrowsize=0.5,style="setlinewidth(0.5)"];
	}

.. autoclass:: GlIGeomFunctor
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Gl1_Dem3DofGeom_FacetSphere
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Gl1_Dem3DofGeom_SphereSphere
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Gl1_Dem3DofGeom_WallSphere
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Gl1_L3Geom
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Gl1_L6Geom
	:members:
	:undoc-members:
	:inherited-members:



GlIPhysFunctor
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. graphviz::

	digraph GlIPhysFunctor {
		rankdir=RL;
		margin=.2;
		"GlIPhysFunctor" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.GlIPhysFunctor"];
		"Gl1_CpmPhys" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Gl1_CpmPhys"];
		"Gl1_CpmPhys" -> "GlIPhysFunctor" [arrowsize=0.5,style="setlinewidth(0.5)"];
		"Gl1_NormPhys" [shape="box",fontsize=8,style="setlinewidth(0.5),solid",height=0.2,URL="yade.wrapper.html#yade.wrapper.Gl1_NormPhys"];
		"Gl1_NormPhys" -> "GlIPhysFunctor" [arrowsize=0.5,style="setlinewidth(0.5)"];
	}

.. autoclass:: GlIPhysFunctor
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Gl1_CpmPhys
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Gl1_NormPhys
	:members:
	:undoc-members:
	:inherited-members:


Simulation data
----------------------------------------------------------------------------------------------------



Omega
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. autoclass:: Omega
	:members:
	:undoc-members:
	:inherited-members:



BodyContainer
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. autoclass:: BodyContainer
	:members:
	:undoc-members:
	:inherited-members:



InteractionContainer
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. autoclass:: InteractionContainer
	:members:
	:undoc-members:
	:inherited-members:



ForceContainer
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. autoclass:: ForceContainer
	:members:
	:undoc-members:
	:inherited-members:



MaterialContainer
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. autoclass:: MaterialContainer
	:members:
	:undoc-members:
	:inherited-members:



Scene
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. autoclass:: Scene
	:members:
	:undoc-members:
	:inherited-members:



Cell
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. autoclass:: Cell
	:members:
	:undoc-members:
	:inherited-members:



Other classes
---------------

.. autoclass:: Engine
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Cell
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: TimingDeltas
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: GlExtraDrawer
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: GlIGeomDispatcher
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: ParallelEngine
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: GlShapeDispatcher
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Functor
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Serializable
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: GlExtra_LawTester
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: GlStateDispatcher
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: MatchMaker
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: GlBoundDispatcher
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: GlIPhysDispatcher
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: GlExtra_OctreeCubes
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: Dispatcher
	:members:
	:undoc-members:
	:inherited-members:

.. autoclass:: EnergyTracker
	:members:
	:undoc-members:
	:inherited-members:

