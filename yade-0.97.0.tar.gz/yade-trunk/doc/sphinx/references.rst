References
============

All external articles referenced in Yade documentation.

.. note:: This file is generated from :ysrc:`doc/references.bib`.

.. [Addetta2001] \ G.A. D'Addetta, F. Kun, E. Ramm, H.J. Herrmann (2001), **From solids to granulates - Discrete element simulations of fracture and fragmentation processes in geomaterials.**. In *Continuous and Discontinuous Modelling of Cohesive-Frictional Materials*. `(fulltext) <http://www.comphys.ethz.ch/hans/p/267.pdf>`__

.. [Allen1989] \ M. P. Allen, D. J. Tildesley (1989), **Computer simulation of liquids**. Clarendon Press.

.. [Alonso2004] \ F. Alonso-Marroquin, R. Garcia-Rojo, H.J. Herrmann (2004), **Micro-mechanical investigation of the granular ratcheting**. In *Cyclic Behaviour of Soils and Liquefaction Phenomena*. `(fulltext) <http://www.comphys.ethz.ch/hans/p/334.pdf>`__

.. [Bagi2006] \ Katalin Bagi (2006), **Analysis of microstructural strain tensors for granular assemblies**. *International Journal of Solids and Structures* (43), pages 3166 - 3184. DOI `10.1016/j.ijsolstr.2005.07.016 <http://dx.doi.org/10.1016/j.ijsolstr.2005.07.016>`_

.. [Bertrand2005] \ D. Bertrand, F. Nicot, P. Gotteland, S. Lambert (2005), **Modelling a geo-composite cell using discrete analysis**. *Computers and Geotechnics* (32), pages 564--577.

.. [Bertrand2008] \ D. Bertrand, F. Nicot, P. Gotteland, S. Lambert (2008), **Discrete element method (dem) numerical modeling of double-twisted hexagonal mesh**. *Canadian Geotechnical Journal* (45), pages 1104--1117.

.. [Calvetti1997] \ Calvetti, F., Combe, G., Lanier, J. (1997), **Experimental micromechanical analysis of a 2d granular material: relation between structure evolution and loading path**. *Mechanics of Cohesive-frictional Materials* (2), pages 121--163.

.. [Camborde2000a] \ F. Camborde, C. Mariotti, F.V. Donzé (2000), **Numerical study of rock and concrete behaviour by discrete element modelling**. *Computers and Geotechnics* (27), pages 225--247.

.. [Chareyre2002a] \ B. Chareyre, L. Briancon, P. Villard (2002), **Theoretical versus experimental modeling of the anchorage capacity of geotextiles in trenches.**. *Geosynthet. Int.* (9), pages 97--123.

.. [Chareyre2002b] \ B. Chareyre, P. Villard (2002), **Discrete element modeling of curved geosynthetic anchorages with known macro-properties.**. In *Proc., First Int. PFC Symposium, Gelsenkirchen, Germany*.

.. [Chareyre2003] \ Bruno Chareyre (2003), **Modélisation du comportement d'ouvrages composites sol-géosynthétique par éléments discrets - application aux tranchées d'ancrage en tête de talus.**. PhD thesis at *Grenoble University*. `(fulltext) <http://tel.archives-ouvertes.fr/tel-00486807/fr/>`__

.. [Chareyre2005] \ Bruno Chareyre, Pascal Villard (2005), **Dynamic spar elements and discrete element methods in two dimensions for the modeling of soil-inclusion problems**. *Journal of Engineering Mechanics* (131), pages 689--698. DOI `10.1061/(ASCE)0733-9399(2005)131:7(689) <http://dx.doi.org/10.1061/(ASCE)0733-9399(2005)131:7(689)>`_ `(fulltext) <https://yade-dem.org/wiki/File:Chareyre%26Villard2005_licensed.pdf>`__

.. [CundallStrack1979] \ P.A. Cundall, O.D.L. Strack (1979), **A discrete numerical model for granular assemblies**. *Geotechnique* (), pages 47--65. DOI `10.1680/geot.1979.29.1.47 <http://dx.doi.org/10.1680/geot.1979.29.1.47>`_

.. [DeghmReport2006] \ F. V. Donzé (ed.), **Annual report 2006** (2006). *Discrete Element Group for Hazard Mitigation*. Université Joseph Fourier, Grenoble `(fulltext) <http://geo.hmg.inpg.fr/frederic/Discrete_Element_Group_FVD.html>`__

.. [Donze1994a] \ F.V. Donzé, P. Mora, S.A. Magnier (1994), **Numerical simulation of faults and shear zones**. *Geophys. J. Int.* (116), pages 46--52.

.. [Donze1995a] \ F.V. Donzé, S.A. Magnier (1995), **Formulation of a three-dimensional numerical model of brittle behavior**. *Geophys. J. Int.* (122), pages 790--802.

.. [Donze1999a] \ F.V. Donzé, S.A. Magnier, L. Daudeville, C. Mariotti, L. Davenne (1999), **Study of the behavior of concrete at high strain rate compressions by a discrete element method**. *ASCE J. of Eng. Mech* (125), pages 1154--1163. DOI `10.1016/S0266-352X(00)00013-6 <http://dx.doi.org/10.1016/S0266-352X(00)00013-6>`_

.. [Donze2004a] \ F.V. Donzé, P. Bernasconi (2004), **Simulation of the blasting patterns in shaft sinking using a discrete element method**. *Electronic Journal of Geotechnical Engineering* (9), pages 1--44.

.. [Duriez2010] \ J. Duriez, F.Darve, F.-V.Donze (2010), **A discrete modeling-based constitutive relation for infilled rock joints**. *International Journal of Rock Mechanics & Mining Sciences*. (in press)

.. [GarciaRojo2004] \ R. García-Rojo, S. McNamara, H. J. Herrmann (2004), **Discrete element methods for the micro-mechanical investigation of granular ratcheting**. In *Proceedings ECCOMAS 2004*. `(fulltext) <http://www.ica1.uni-stuttgart.de/publications/2004/GMH04>`__

.. [Hentz2003] \ Séebastien Hentz (2003), **Modélisation d'une structure en béton armé soumise à un choc par la méthode des eléments discrets**. PhD thesis at *Université Grenoble 1 -- Joseph Fourier*.

.. [Hentz2004a] \ S. Hentz, F.V. Donzé, L.Daudeville (2004), **Discrete element modelling of concrete submitted to dynamic loading at high strain rates**. *Computers and Structures* (82), pages 2509--2524. DOI `10.1016/j.compstruc.2004.05.016 <http://dx.doi.org/10.1016/j.compstruc.2004.05.016>`_

.. [Hentz2004b] \ S. Hentz, L. Daudeville, F.V. Donzé (2004), **Identification and validation of a discrete element model for concrete**. *ASCE Journal of Engineering Mechanics* (130), pages 709--719. DOI `10.1061/(ASCE)0733-9399(2004)130:6(709) <http://dx.doi.org/10.1061/(ASCE)0733-9399(2004)130:6(709)>`_

.. [Hentz2005a] \ S. Hentz, F.V. Donzé, L.Daudeville (2005), **Discrete elements modeling of a reinforced concrete structure submitted to a rock impact**. *Italian Geotechnical Journal* (XXXIX), pages 83--94.

.. [Herminghaus2005] \ Herminghaus * , S. (2005), **Dynamics of wet granular matter**. *Advances in Physics* (54), pages 221-261. DOI `10.1080/00018730500167855 <http://dx.doi.org/10.1080/00018730500167855>`_ `(fulltext) <http://www.tandfonline.com/doi/abs/10.1080/00018730500167855>`__

.. [Hubbard1996] \ Philip M. Hubbard (1996), **Approximating polyhedra with spheres for time-critical collision detection**. *ACM Trans. Graph.* (15), pages 179--210. DOI `10.1145/231731.231732 <http://dx.doi.org/10.1145/231731.231732>`_

.. [Johnson2008] \ Scott M. Johnson, John R. Williams, Benjamin K. Cook (2008), **Quaternion-based rigid body rotation integration algorithms for use in particle methods**. *International Journal for Numerical Methods in Engineering* (74), pages 1303--1313. DOI `10.1002/nme.2210 <http://dx.doi.org/10.1002/nme.2210>`_

.. [Jung1997] \ Derek Jung, Kamal K. Gupta (1997), **Octree-based hierarchical distance maps for collision detection**. *Journal of Robotic Systems* (14), pages 789--806. DOI `10.1002/(SICI)1097-4563(199711)14:11<789::AID-ROB3>3.0.CO;2-Q <http://dx.doi.org/10.1002/(SICI)1097-4563(199711)14:11%3c789::AID-ROB3%3e3.0.CO;2-Q>`_

.. [Kettner2011] \ Lutz Kettner, Andreas Meyer, Afra Zomorodian (2011), **Intersecting sequences of dD iso-oriented boxes**. In *CGAL User and Reference Manual*. `(fulltext) <http://www.cgal.org/Manual/3.9/doc_html/cgal_manual/packages.html#Pkg:BoxIntersectionD>`__

.. [Klosowski1998] \ James T. Klosowski, Martin Held, Joseph S. B. Mitchell, Henry Sowizral, Karel Zikan (1998), **Efficient collision detection using bounding volume hierarchies of k-dops**. *IEEE Transactions on Visualization and Computer Graphics* (4), pages 21--36. `(fulltext) <http://citeseerx.ist.psu.edu/viewdoc/download?doi=10.1.1.105.6555&rep=rep1&type=pdf>`__

.. [Kuhl2001] \ E. Kuhl, G. A. D'Addetta, M. Leukart, E. Ramm (2001), **Microplane modelling and particle modelling of cohesive-frictional materials**. In *Continuous and Discontinuous Modelling of Cohesive-Frictional Materials*. DOI `10.1007/3-540-44424-6_3 <http://dx.doi.org/10.1007/3-540-44424-6_3>`_ `(fulltext) <http://www.springerlink.com/content/e50544266r506615>`__

.. [Lu1998] \ Ya Yan Lu (1998), **Computing the logarithm of a symmetric positive definite matrix**. *Appl. Numer. Math* (26), pages 483--496. DOI `10.1016/S0168-9274(97)00103-7 <http://dx.doi.org/10.1016/S0168-9274(97)00103-7>`_ `(fulltext) <http://citeseerx.ist.psu.edu/viewdoc/download?doi=10.1.1.37.759&rep=rep1&type=pdf>`__

.. [Luding2008] \ Luding, Stefan (2008), **Cohesive, frictional powders: contact models for tension**. *Granular Matter* (10), pages 235-246. DOI `10.1007/s10035-008-0099-x <http://dx.doi.org/10.1007/s10035-008-0099-x>`_ `(fulltext) <http://dx.doi.org/10.1007/s10035-008-0099-x>`__

.. [Magnier1998a] \ S.A. Magnier, F.V. Donzé (1998), **Numerical simulation of impacts using a discrete element method**. *Mech. Cohes.-frict. Mater.* (3), pages 257--276. DOI `10.1002/(SICI)1099-1484(199807)3:3<257::AID-CFM50>3.0.CO;2-Z <http://dx.doi.org/10.1002/(SICI)1099-1484(199807)3:3%3c257::AID-CFM50%3e3.0.CO;2-Z>`_

.. [McNamara2008] \ S. McNamara, R. García-Rojo, H. J. Herrmann (2008), **Microscopic origin of granular ratcheting**. *Physical Review E* (77). DOI `11.1103/PhysRevE.77.031304 <http://dx.doi.org/11.1103/PhysRevE.77.031304>`_

.. [Munjiza1998] \ A. Munjiza, K. R. F. Andrews (1998), **Nbs contact detection algorithm for bodies of similar size**. *International Journal for Numerical Methods in Engineering* (43), pages 131--149. DOI `10.1002/(SICI)1097-0207(19980915)43:1<131::AID-NME447>3.0.CO;2-S <http://dx.doi.org/10.1002/(SICI)1097-0207(19980915)43:1%3c131::AID-NME447%3e3.0.CO;2-S>`_

.. [Munjiza2006] \ A. Munjiza, E. Rougier, N. W. M. John (2006), **Mr linear contact detection algorithm**. *International Journal for Numerical Methods in Engineering* (66), pages 46--71. DOI `10.1002/nme.1538 <http://dx.doi.org/10.1002/nme.1538>`_

.. [Neto2006] \ Natale Neto, Luca Bellucci (2006), **A new algorithm for rigid body molecular dynamics**. *Chemical Physics* (328), pages 259--268. DOI `10.1016/j.chemphys.2006.07.009 <http://dx.doi.org/10.1016/j.chemphys.2006.07.009>`_

.. [Omelyan1999] \ Igor P. Omelyan (1999), **A new leapfrog integrator of rotational motion. the revised angular-momentum approach**. *Molecular Simulation* (22). DOI `10.1080/08927029908022097 <http://dx.doi.org/10.1080/08927029908022097>`_ `(fulltext) <http://arxiv.org/pdf/physics/9901025>`__

.. [Pfc3dManual30] \ ICG (2003), **Pfc3d (particle flow code in 3d) theory and background manual, version 3.0**. Itasca Consulting Group.

.. [Pion2011] \ Sylvain Pion, Monique Teillaud (2011), **3D triangulations**. In *CGAL User and Reference Manual*. `(fulltext) <http://www.cgal.org/Manual/3.9/doc_html/cgal_manual/packages.html#Pkg:Triangulation3>`__

.. [Pournin2001] \ L. Pournin, Th. M. Liebling, A. Mocellin (2001), **Molecular-dynamics force models for better control of energy dissipation in numerical simulations of dense granular media**. *Phys. Rev. E* (65), pages 011302. DOI `10.1103/PhysRevE.65.011302 <http://dx.doi.org/10.1103/PhysRevE.65.011302>`_

.. [Price2007] \ Mathew Price, Vasile Murariu, Garry Morrison (2007), **Sphere clump generation and trajectory comparison for real particles**. In *Proceedings of Discrete Element Modelling 2007*. `(fulltext) <http://www.cogency.co.za/images/info/dem2007_sphereclump.pdf>`__

.. [Rabinov2005] \ RABINOVICH Yakov I., ESAYANUR Madhavan S., MOUDGIL Brij M. (2005), **Capillary forces between two spheres with a fixed volume liquid bridge : theory and experiment**. *Langmuir* (21), pages 10992--10997. `(fulltext) <http://www.refdoc.fr/Detailnotice?idarticle=7435486>`__ (eng)

.. [Satake1982] \ M. Satake (1982), **Fabric tensor in granular materials.**. In *Proc., IUTAM Symp. on Deformation and Failure of Granular materials, Delft, The Netherlands*.

.. [Thoeni2013] \ K. Thoeni, C. Lambert, A. Giacomini, S.W. Sloan (2013), **Discrete modelling of hexagonal wire meshes with a stochastically distorted contact model**. *Computers and Geotechnics* (49), pages 158--169. DOI `10.1016/j.compgeo.2012.10.014 <http://dx.doi.org/10.1016/j.compgeo.2012.10.014>`_ `(fulltext) <http://www.sciencedirect.com/science/article/pii/S0266352X12002121>`__

.. [Thornton1991] \ Colin Thornton, K. K. Yin (1991), **Impact of elastic spheres with and without adhesion**. *Powder technology* (65), pages 153--166. DOI `10.1016/0032-5910(91)80178-L <http://dx.doi.org/10.1016/0032-5910(91)80178-L>`_

.. [Thornton2000] \ Colin Thornton (2000), **Numerical simulations of deviatoric shear deformation of granular media**. *Géotechnique* (50), pages 43--53. DOI `10.1680/geot.2000.50.1.43 <http://dx.doi.org/10.1680/geot.2000.50.1.43>`_

.. [Verlet1967] \ Loup Verlet (1967), **Computer ``experiments'' on classical fluids. i. thermodynamical properties of lennard-jones molecules**. *Phys. Rev.* (159), pages 98. DOI `10.1103/PhysRev.159.98 <http://dx.doi.org/10.1103/PhysRev.159.98>`_

.. [Villard2004a] \ P. Villard, B. Chareyre (2004), **Design methods for geosynthetic anchor trenches on the basis of true scale experiments and discrete element modelling**. *Canadian Geotechnical Journal* (41), pages 1193--1205.

.. [Wang2009] \ Yucang Wang (2009), **A new algorithm to model the dynamics of 3-d bonded rigid bodies with rotations**. *Acta Geotechnica* (4), pages 117--127. DOI `10.1007/s11440-008-0072-1 <http://dx.doi.org/10.1007/s11440-008-0072-1>`_ `(fulltext) <http://www.springerlink.com/content/l2306412v1004871/>`__

.. [Weigert1999] \ Weigert, Tom, Ripperger, Siegfried (1999), **Calculation of the liquid bridge volume and bulk saturation from the half-filling angle**. *Particle & Particle Systems Characterization* (16), pages 238--242. DOI `10.1002/(SICI)1521-4117(199910)16:5<238::AID-PPSC238>3.0.CO;2-E <http://dx.doi.org/10.1002/(SICI)1521-4117(199910)16:5%3c238::AID-PPSC238%3e3.0.CO;2-E>`_ `(fulltext) <http://dx.doi.org/10.1002/(SICI)1521-4117(199910)16:5%3c238::AID-PPSC238%3e3.0.CO;2-E>`__

.. [Willett2000] \ Willett, Christopher D., Adams, Michael J., Johnson, Simon A., Seville, Jonathan P. K. (2000), **Capillary bridges between two spherical bodies**. *Langmuir* (16), pages 9396-9405. DOI `10.1021/la000657y <http://dx.doi.org/10.1021/la000657y>`_ `(fulltext) <http://pubs.acs.org/doi/abs/10.1021/la000657y>`__

.. [cgal] \ Jean-Daniel Boissonnat, Olivier Devillers, Sylvain Pion, Monique Teillaud, Mariette Yvinec (2002), **Triangulations in cgal**. *Computational Geometry: Theory and Applications* (22), pages 5--19.
