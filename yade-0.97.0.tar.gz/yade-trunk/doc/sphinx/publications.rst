Publications on Yade
=====================
This page should be a relatively complete list of publications on Yade itself or done with Yade. If you publish something, do not hesitate to add it on the list. If PDF is freely available, add url for direct fulltext downlad. If not, consider uploading fulltext in PDF, either to `Yade wiki <https://www.yade-dem.org/wiki/>`_ or to other website, if legally permitted.

The last section gives the references that we recommend to use for citing Yade in publications, as explained in the `"Acknowledging Yade" <citing.html>`_ section.

.. note:: This file is generated from :ysrc:`doc/yade-articles.bib`, :ysrc:`doc/yade-conferences.bib`, :ysrc:`doc/yade-theses.bib` and :ysrc:`doc/yade-docref.bib`.

Citing Yade
---------------------
Corresponding bibtex entries `here <http://bazaar.launchpad.net/~yade-dev/yade/trunk/view/head:/doc/citing_yade.bib>`_. Pdf versions are available for each of them. See also `"Acknowledging Yade" <citing.html>`_.

.. [yade:background] \ V. Šmilauer, B. Chareyre (2010), **Yade dem formulation**. In *Yade Documentation* ( V. Šmilauer, ed.), The Yade Project , 1st ed. `(fulltext) <https://yade-dem.org/w/images/e/e0/YadeFormulation.pdf>`__ (http://yade-dem.org/doc/formulation.html)

.. [yade:doc] \ V. Šmilauer, E. Catalano, B. Chareyre, S. Dorofeenko, J. Duriez, A. Gladky, J. Kozicki, C. Modenese, L. Scholtès, L. Sibille, J. Stránský, K. Thoeni (2010), **Yade Documentation**. The Yade Project. (http://yade-dem.org/doc/)

.. [yade:manual] \ V. Šmilauer, A. Gladky, J. Kozicki, C. Modenese, J. Stránský (2010), **Yade, using and programming**. In *Yade Documentation* ( V. Šmilauer, ed.), The Yade Project , 1st ed. `(fulltext) <https://yade-dem.org/w/images/0/09/YadeManuals.pdf>`__ (http://yade-dem.org/doc/)

.. [yade:reference] \ V. Šmilauer, E. Catalano, B. Chareyre, S. Dorofeenko, J. Duriez, A. Gladky, J. Kozicki, C. Modenese, L. Scholtès, L. Sibille, J. Stránský, K. Thoeni (2010), **Yade Reference Documentation**. In *Yade Documentation* ( V. Šmilauer, ed.), The Yade Project , 1st ed. `(fulltext) <https://yade-dem.org/w/images/9/98/YadeRefDoc.pdf>`__ (http://yade-dem.org/doc/)

Journal articles
-----------------
.. [Boon2012a] \ Boon,C.W., Houlsby, G.T., Utili, S. (2012), **A new algorithm for contact detection between convex polygonal and polyhedral particles in the discrete element method**. *Computers and Geotechnics* (44), pages 73 - 82. DOI `10.1016/j.compgeo.2012.03.012 <http://dx.doi.org/10.1016/j.compgeo.2012.03.012>`_ `(fulltext) <http://www.sciencedirect.com/science/article/pii/S0266352X12000535>`__

.. [Boon2012b] \ Boon,C.W., Houlsby, G.T., Utili, S. (2013), **A new contact detection algorithm for three-dimensional non-spherical particles**. *Powder Technology*. DOI `10.1016/j.powtec.2012.12.040 <http://dx.doi.org/10.1016/j.powtec.2012.12.040>`_ `(fulltext) <http://www.sciencedirect.com/science/article/pii/S003259101200839X>`__

.. [Bourrier2013] \ Bourrier, F., Kneib, F., Chareyre, B., Fourcaud, T. (2013), **Discrete modeling of granular soils reinforcement by plant roots**. *Ecological Engineering*. DOI `10.1016/j.ecoleng.2013.05.002 <http://dx.doi.org/10.1016/j.ecoleng.2013.05.002>`_ `(fulltext) <http://dx.doi.org/10.1016/j.ecoleng.2013.05.002>`__

.. [Catalano2013a] \ Catalano, E., Chareyre, B., Barthélémy, E. (2013), **Pore-scale modeling of fluid-particles interaction and emerging poromechanical effects**. *International Journal for Numerical and Analytical Methods in Geomechanics*. DOI `10.1002/nag.2198 <http://dx.doi.org/10.1002/nag.2198>`_ `(fulltext) <http://arxiv.org/pdf/1304.4895.pdf>`__ (in press, arxiv version available)

.. [Chareyre2012a] \ Chareyre, B., Cortis, A., Catalano, E., Barthélemy, E. (2012), **Pore-scale modeling of viscous flow and induced forces in dense sphere packings**. *Transport in Porous Media* (92), pages 473-493. DOI `10.1007/s11242-011-9915-6 <http://dx.doi.org/10.1007/s11242-011-9915-6>`_ `(fulltext) <http://dx.doi.org/10.1007/s11242-011-9915-6>`__

.. [Chen2007] \ Chen, F., Drumm, E. C., Guiochon, G. (2007), **Prediction/verification of particle motion in one dimension with the discrete-element method**. *International Journal of Geomechanics, ASCE* (7), pages 344--352. DOI `10.1061/(ASCE)1532-3641(2007)7:5(344) <http://dx.doi.org/10.1061/(ASCE)1532-3641(2007)7:5(344)>`_

.. [Chen2011a] \ Chen, F., Drumm, E., Guiochon G. (2011), **Coupled discrete element and finite volume solution of two classical soil mechanics problems**. *Computers and Geotechnics*. DOI `10.1016/j.compgeo.2011.03.009 <http://dx.doi.org/10.1016/j.compgeo.2011.03.009>`_ `(fulltext) <http://www.sciencedirect.com/science/article/pii/S0266352X11000504>`__

.. [Chen2012] \ Chen, Jingsong, Huang, Baoshan, Chen, Feng, Shu, Xiang (2012), **Application of discrete element method to superpave gyratory compaction**. *Road Materials and Pavement Design* (13), pages 480-500. DOI `10.1080/14680629.2012.694160 <http://dx.doi.org/10.1080/14680629.2012.694160>`_ `(fulltext) <http://www.tandfonline.com/doi/abs/10.1080/14680629.2012.694160>`__

.. [Dang2010a] \ Dang, H. K., Meguid, M. A. (2010), **Algorithm to generate a discrete element specimen with predefined properties**. *International Journal of Geomechanics* (10), pages 85-91. DOI `10.1061/(ASCE)GM.1943-5622.0000028 <http://dx.doi.org/10.1061/(ASCE)GM.1943-5622.0000028>`_

.. [Dang2010b] \ Dang, H. K., Meguid, M. A. (2010), **Evaluating the performance of an explicit dynamic relaxation technique in analyzing non-linear geotechnical engineering problems**. *Computers and Geotechnics* (37), pages 125 - 131. DOI `10.1016/j.compgeo.2009.08.004 <http://dx.doi.org/10.1016/j.compgeo.2009.08.004>`_

.. [Donze2008] \ Donzé, F.V. (2008), **Impacts on cohesive frictional geomaterials**. *European Journal of Environmental and Civil Engineering* (12), pages 967--985.

.. [Duriez2011a] \ Duriez,J., Darve, F., Donzé, F.V. (2011), **A discrete modeling-based constitutive relation for infilled rock joints**. *International Journal of Rock Mechanics & Mining Sciences* (48), pages 458--468. DOI `10.1016/j.ijrmms.2010.09.008 <http://dx.doi.org/10.1016/j.ijrmms.2010.09.008>`_

.. [Duriez2011b] \ Duriez, J., Darve, F., Donzé, F.V. (2011), **Incrementally non-linear plasticity applied to rock joint modelling**. *International Journal for Numerical and Analytical Methods in Geomechanics*. DOI `10.1002/nag.1105 <http://dx.doi.org/10.1002/nag.1105>`_

.. [Duriez2011c] \ Duriez,J., Darve, F., Donzé, F.V. (2011), **A discrete modeling-based constitutive relation for infilled rock joints**. *International Journal of Rock Mechanics & Mining Sciences* (48), pages 458--468. DOI `10.1016/j.ijrmms.2010.09.008 <http://dx.doi.org/10.1016/j.ijrmms.2010.09.008>`_

.. [Duriez2013] \ Duriez, J., Darve, F., Donzé, F.V. (2013), **Incrementally non-linear plasticity applied to rock joint modelling**. *International Journal for Numerical and Analytical Methods in Geomechanics* (37), pages 453--477. DOI `10.1002/nag.1105 <http://dx.doi.org/10.1002/nag.1105>`_ `(fulltext) <http://dx.doi.org/10.1002/nag.1105>`__

.. [Epifancev2013] \ Epifancev, K., Nikulin, A., Kovshov, S., Mozer, S., Brigadnov, I. (2013), **Modeling of peat mass process formation based on 3d analysis of the screw machine by the code yade**. *American Journal of Mechanical Engineering* (1), pages 73--75. DOI `10.12691/ajme-1-3-3 <http://dx.doi.org/10.12691/ajme-1-3-3>`_ `(fulltext) <http://pubs.sciepub.com/ajme/1/3/3>`__

.. [Epifantsev2012] \ Epifantsev, K., Mikhailov, A., Gladky, A. (2012), **Proizvodstvo kuskovogo torfa, ekstrudirovanie, forma zakhodnoi i kalibriruyushchei chasti fil'ery matritsy, metod diskretnykh elementov [rus]**. *Mining informational and analytical bulletin (scientific and technical journal)*, pages 212-219.

.. [Favier2009a] \ Favier, L., Daudon, D., Donzé, F.V., Mazars, J. (2009), **Predicting the drag coefficient of a granular flow using the discrete element method**. *Journal of Statistical Mechanics: Theory and Experiment* (2009), pages P06012.

.. [Favier2012] \ Favier, L., Daudon, D., Donzé, F.V. (2012), **Rigid obstacle impacted by a supercritical cohesive granular flow using a 3d discrete element model**. *Cold Regions Science and Technology* (85), pages 232--241. `(fulltext) <http://dx.doi.org/10.1016/j.coldregions.2012.09.010>`__

.. [Grujicic2013] \ Grujicic, M, Snipes, JS, Ramaswami, S, Yavari, R (2013), **Discrete element modeling and analysis of structural collapse/survivability of a building subjected to improvised explosive device (ied) attack**. *Advances in Materials Science and Applications* (2), pages 9--24.

.. [Gusenbauer2012] \ Gusenbauer, M., Kovacs, A., Reichel, F., Exl, L., Bance, S., �zelt, H., Schrefl, T. (2012), **Self-organizing magnetic beads for biomedical applications**. *Journal of Magnetism and Magnetic Materials* (324), pages 977--982.

.. [Hadda2013] \ Hadda, Nejib, Nicot, François, Bourrier, Franck, Sibille, Luc, Radjai, Farhang, Darve, Félix (2013), **Micromechanical analysis of second order work in granular media**. *Granular Matter* (15), pages 221--235. DOI `10.1007/s10035-013-0402-3 <http://dx.doi.org/10.1007/s10035-013-0402-3>`_ `(fulltext) <http://dx.doi.org/10.1007/s10035-013-0402-3>`__

.. [Harthong2009] \ Harthong, B., Jerier, J.F., Doremus, P., Imbault, D., Donzé, F.V. (2009), **Modeling of high-density compaction of granular materials by the discrete element method**. *International Journal of Solids and Structures* (46), pages 3357--3364. DOI `10.1016/j.ijsolstr.2009.05.008 <http://dx.doi.org/10.1016/j.ijsolstr.2009.05.008>`_

.. [Harthong2012b] \ Harthong, B., Jerier, J.-F., Richefeu, V., Chareyre, B., Doremus, P., Imbault, D., Donzé, F.V. (2012), **Contact impingement in packings of elastic–plastic spheres, application to powder compaction**. *International Journal of Mechanical Sciences* (61), pages 32–43.

.. [Hartong2012a] \ Harthong, B., Scholtès, L., Donzé, F.-V. (2012), **Strength characterization of rock masses, using a coupled dem–dfn model**. *Geophysical Journal International* (191), pages 467--480. DOI `10.1111/j.1365-246X.2012.05642.x <http://dx.doi.org/10.1111/j.1365-246X.2012.05642.x>`_ `(fulltext) <http://dx.doi.org/10.1111/j.1365-246X.2012.05642.x>`__

.. [Hassan2010] \ Hassan, A., Chareyre, B., Darve, F., Meyssonier, J., Flin, F. (2010 (submitted)), **Microtomography-based discrete element modelling of creep in snow**. *Granular Matter*.

.. [Jerier2009] \ Jerier, J.-F., Imbault, D.and Donzé, F.V., Doremus, P. (2009), **A geometric algorithm based on tetrahedral meshes to generate a dense polydisperse sphere packing**. *Granular Matter* (11). DOI `10.1007/s10035-008-0116-0 <http://dx.doi.org/10.1007/s10035-008-0116-0>`_

.. [Jerier2010a] \ Jerier, J.-F., Richefeu, V., Imbault, D., Donzé, F.V. (2010), **Packing spherical discrete elements for large scale simulations**. *Computer Methods in Applied Mechanics and Engineering*. DOI `10.1016/j.cma.2010.01.016 <http://dx.doi.org/10.1016/j.cma.2010.01.016>`_

.. [Jerier2010b] \ Jerier, J.-F., Hathong, B., Richefeu, V., Chareyre, B., Imbault, D., Donzé, F.-V., Doremus, P. (2010), **Study of cold powder compaction by using the discrete element method**. *Powder Technology* (In Press). DOI `10.1016/j.powtec.2010.08.056 <http://dx.doi.org/10.1016/j.powtec.2010.08.056>`_

.. [Kozicki2005a] \ Kozicki, J. (2005), **Discrete lattice model used to describe the fracture process of concrete**. *Discrete Element Group for Risk Mitigation Annual Report 1, Grenoble University of Joseph Fourier, France*, pages 95--101. `(fulltext) <https://yade-dem.org/w/images/f/f0/Discrete_lattice_model_DEM_risk_mitigation_kozicki.pdf>`__

.. [Kozicki2006a] \ Kozicki, J., Tejchman, J. (2006), **2D lattice model for fracture in brittle materials**. *Archives of Hydro-Engineering and Environmental Mechanics* (53), pages 71--88. `(fulltext) <https://yade-dem.org/w/images/5/54/Ahem_2006_kozicki.pdf>`__

.. [Kozicki2007a] \ Kozicki, J., Tejchman, J. (2007), **Effect of aggregate structure on fracture process in concrete using 2d lattice model”**. *Archives of Mechanics* (59), pages 365--384. `(fulltext) <https://yade-dem.org/w/images/0/09/Ams_2007_kozicki_tejchman.pdf>`__

.. [Kozicki2008] \ Kozicki, J., Donzé, F.V. (2008), **A new open-source software developed for numerical simulations using discrete modeling methods**. *Computer Methods in Applied Mechanics and Engineering* (197), pages 4429--4443. DOI `10.1016/j.cma.2008.05.023 <http://dx.doi.org/10.1016/j.cma.2008.05.023>`_ `(fulltext) <https://yade-dem.org/w/images/3/30/CMAME_YADE_2008.pdf>`__

.. [Kozicki2009] \ Kozicki, J., Donzé, F.V. (2009), **Yade-open dem: an open-source software using a discrete element method to simulate granular material**. *Engineering Computations* (26), pages 786--805. DOI `10.1108/02644400910985170 <http://dx.doi.org/10.1108/02644400910985170>`_ `(fulltext) <https://yade-dem.org/w/images/8/80/EC_YADE_2008.pdf>`__

.. [Lomine2013] \ Lominé, F., Scholtès, L., Sibille, L., Poullain, P. (2013), **Modelling of fluid-solid interaction in granular media with coupled lb/de methods: application to piping erosion**. *International Journal for Numerical and Analytical Methods in Geomechanics* (37), pages 577-596. DOI `10.1002/nag.1109 <http://dx.doi.org/10.1002/nag.1109>`_

.. [Nicot2011] \ Nicot, F., Hadda, N., Bourrier, F., Sibille, L., Darve, F. (2011), **Failure mechanisms in granular media: a discrete element analysis**. *Granular Matter* (13), pages 255-260. DOI `10.1007/s10035-010-0242-3 <http://dx.doi.org/10.1007/s10035-010-0242-3>`_

.. [Nicot2012] \ Nicot, F., Sibille, L., Darve, F. (2012), **Failure in rate-independent granular materials as a bifurcation toward a dynamic regime**. *International Journal of Plasticity* (29), pages 136-154. DOI `10.1016/j.ijplas.2011.08.002 <http://dx.doi.org/10.1016/j.ijplas.2011.08.002>`_

.. [Nicot2013a] \ Nicot, F., Hadda, N., Darve, F. (2013), **Second-order work analysis for granular materials using a multiscale approach**. *International Journal for Numerical and Analytical Methods in Geomechanics*. DOI `10.1002/nag.2175 <http://dx.doi.org/10.1002/nag.2175>`_

.. [Nicot2013b] \ Nicot, F., Hadda, N., Guessasma, M., Fortin, J., Millet, O. (2013), **On the definition of the stress tensor in granular media**. *International Journal of Solids and Structures*. DOI `10.1016/j.ijsolstr.2013.04.001 <http://dx.doi.org/10.1016/j.ijsolstr.2013.04.001>`_ `(fulltext) <http://www.sciencedirect.com/science/article/pii/S0020768313001492>`__

.. [Puckett2011] \ Puckett, J.G., Lechenault, F., Daniels, K.E. (2011), **Local origins of volume fraction fluctuations in dense granular materials**. *Physical Review E*4 (83), pages 041301. DOI `10.1103/PhysRevE.83.041301 <http://dx.doi.org/10.1103/PhysRevE.83.041301>`_ `(fulltext) <http://link.aps.org/doi/10.1103/PhysRevE.83.041301>`__

.. [Sayeed2011] \ Sayeed, M.A., Suzuki, K., Rahman, M.M., Mohamad, W.H.W., Razlan, M.A., Ahmad, Z., Thumrongvut, J., Seangatith, S., Sobhan, MA, Mofiz, SA, others (2011), **Strength and deformation characteristics of granular materials under extremely low to high confining pressures in triaxial compression**. *International Journal of Civil & Environmental Engineering IJCEE-IJENS* (11).

.. [Scholtes2009a] \ Scholtès, L., Chareyre, B., Nicot, F., Darve, F. (2009), **Micromechanics of granular materials with capillary effects**. *International Journal of Engineering Science* (47), pages 64--75. DOI `10.1016/j.ijengsci.2008.07.002 <http://dx.doi.org/10.1016/j.ijengsci.2008.07.002>`_ `(fulltext) <http://dx.doi.org/10.1016/j.ijengsci.2008.07.002>`__

.. [Scholtes2009b] \ Scholtès, L., Hicher, P.-Y., Chareyre, B., Nicot, F., Darve, F. (2009), **On the capillary stress tensor in wet granular materials**. *International Journal for Numerical and Analytical Methods in Geomechanics* (33), pages 1289--1313. DOI `10.1002/nag.767 <http://dx.doi.org/10.1002/nag.767>`_ `(fulltext) <http://arxiv.org/abs/1105.1013>`__

.. [Scholtes2009c] \ Scholtès, L., Chareyre, B., Nicot, F., Darve, F. (2009), **Discrete modelling of capillary mechanisms in multi-phase granular media**. *Computer Modeling in Engineering and Sciences* (52), pages 297--318. `(fulltext) <http://arxiv.org/abs/1203.1234>`__

.. [Scholtes2010] \ Scholtès, L., Hicher, P.-Y., Sibille, L. (2010), **Multiscale approaches to describe mechanical responses induced by particle removal in granular materials**. *Comptes Rendus Mécanique* (338), pages 627--638. DOI `10.1016/j.crme.2010.10.003 <http://dx.doi.org/10.1016/j.crme.2010.10.003>`_ `(fulltext) <http://dx.doi.org/10.1016/j.crme.2010.10.003>`__

.. [Scholtes2011] \ Scholtès, L., Donzé, F.V., Khanal, M. (2011), **Scale effects on strength of geomaterials, case study: coal**. *Journal of the Mechanics and Physics of Solids* (59), pages 1131--1146. DOI `10.1016/j.jmps.2011.01.009 <http://dx.doi.org/10.1016/j.jmps.2011.01.009>`_ `(fulltext) <http://dx.doi.org/10.1016/j.jmps.2011.01.009>`__

.. [Scholtes2012] \ Scholtès, L., Donzé, F.V. (2012), **Modelling progressive failure in fractured rock masses using a 3d discrete element method**. *International Journal of Rock Mechanics and Mining Sciences* (52), pages 18--30. DOI `10.1016/j.ijrmms.2012.02.009 <http://dx.doi.org/10.1016/j.ijrmms.2012.02.009>`_ `(fulltext) <http://dx.doi.org/10.1016/j.ijrmms.2012.02.009>`__

.. [Scholtes2013] \ Scholtès, L., Donzé, F.V. (2013), **A DEM model for soft and hard rocks: role of grain interlocking on strength**. *Journal of the Mechanics and Physics of Solids* (61), pages 352--369. DOI `10.1016/j.jmps.2012.10.005 <http://dx.doi.org/10.1016/j.jmps.2012.10.005>`_ `(fulltext) <http://dx.doi.org/10.1016/j.jmps.2012.10.005>`__

.. [Shiu2008] \ Shiu, W., Donzé, F.V., Daudeville, L. (2008), **Compaction process in concrete during missile impact: a dem analysis**. *Computers and Concrete* (5), pages 329--342.

.. [Shiu2009] \ Shiu, W., Donzé, F.V., Daudeville, L. (2009), **Discrete element modelling of missile impacts on a reinforced concrete target**. *International Journal of Computer Applications in Technology* (34), pages 33--41.

.. [Smilauer2006] \ Václav Šmilauer (2006), **The splendors and miseries of yade design**. *Annual Report of Discrete Element Group for Hazard Mitigation*. `(fulltext) <https://yade-dem.org/w/images/a/a6/Smilauer-the_splendors_and_miseries_of_yade_design-2007.pdf>`__

.. [Tejchman2011] \ Tejchman, J. (2011), **Comparative modelling of shear zone patterns in granular bodies with finite and discrete element model**. *Advances in Bifurcation and Degradation in Geomaterials*, pages 255--260.

.. [Thoeni2013] \ K. Thoeni, C. Lambert, A. Giacomini, S.W. Sloan (2013), **Discrete modelling of hexagonal wire meshes with a stochastically distorted contact model**. *Computers and Geotechnics* (49), pages 158--169. DOI `10.1016/j.compgeo.2012.10.014 <http://dx.doi.org/10.1016/j.compgeo.2012.10.014>`_ `(fulltext) <http://www.sciencedirect.com/science/article/pii/S0266352X12002121>`__

.. [Tong2012] \ Tong, A.-T., Catalano, E., Chareyre, B. (2012), **Pore-scale flow simulations: model predictions compared with experiments on bi-dispersed granular assemblies**. *Oil & Gas Science and Technology - Rev. IFP Energies nouvelles*. DOI `10.2516/ogst/2012032 <http://dx.doi.org/10.2516/ogst/2012032>`_ `(fulltext) <http://dx.doi.org/10.2516/ogst/2012032>`__

.. [Tran2011] \ Tran, V.T., Donzé, F.V., Marin, P. (2011), **A discrete element model of concrete under high triaxial loading**. *Cement and Concrete Composites*.

.. [Tran2012] \ Tran, V.D.H., Meguid, M.A., Chouinard, L.E. (2012), **An algorithm for the propagation of uncertainty in soils using the discrete element method**. *The Electronic Journal of Geotechnical Engineering*. `(fulltext) <http://www.ejge.com/2012/Ppr12.283alr.pdf>`__

.. [Tran2012c] \ Tran, V.D.H., Meguid, M.A., Chouinard, L.E. (2012), **Discrete element and experimental investigations of the earth pressure distribution on cylindrical shafts**. *International Journal of Geomechanics*. DOI `10.1061/(ASCE)GM.1943-5622.0000277 <http://dx.doi.org/10.1061/(ASCE)GM.1943-5622.0000277>`_

.. [Tran2013] \ Tran, V.D.H., Meguid, M.A., Chouinard, L.E. (2013), **A finite--discrete element framework for the 3d modeling of geogrid--soil interaction under pullout loading conditions**. *Geotextiles and Geomembranes* (37), pages 1-9. DOI `10.1016/j.geotexmem.2013.01.003 <http://dx.doi.org/10.1016/j.geotexmem.2013.01.003>`_

Conference materials
---------------------
.. [Catalano2009] \ E. Catalano, B. Chareyre, E. Barthélémy (2009), **Fluid-solid coupling in discrete models**. In *Alert Geomaterials Workshop 2009*.

.. [Catalano2010a] \ E. Catalano, B. Chareyre, E. Barthélémy (2010), **A coupled model for fluid-solid interaction analysis in geomaterials**. In *Alert Geomaterials Workshop 2010*.

.. [Catalano2010b] \ E. Catalano, B. Chareyre, E. Barthélémy (2010), **Pore scale modelling of stokes flow**. In *GdR MeGe*.

.. [Catalano2011a] \ E. Catalano, B. Chareyre, A. Cortis, E. Barthélémy (2011), **A pore-scale hydro-mechanical coupled model for geomaterials**. In *II International Conference on Particle-based Methods - Fundamentals and Applications*. `(fulltext) <http://geo.hmg.inpg.fr/~chareyre/pubs/CatalanoChareyreCortisBarthelemy_Particles2011.pdf>`__

.. [Catalano2013b] \ Catalano E., Chareyre B., Barthélémy E. (2013), **Dem-pfv analysis of solid-fluid transition in granular sediments under the action of waves**. In *Powders and Grains 2013: Proceedings of the 6th International Conference on Micromechanics of Granular Media. AIP Conference Proceedings*. DOI `10.1063/1.4812118 <http://dx.doi.org/10.1063/1.4812118>`_ `(fulltext) <http://link.aip.org/link/?APC/1542/1063/1>`__

.. [Chareyre2009] \ Chareyre B., Scholtès L. (2009), **Micro-statics and micro-kinematics of capillary phenomena in dense granular materials**. In *POWDERS AND GRAINS 2009: Proceedings of the 6th International Conference on Micromechanics of Granular Media. AIP Conference Proceedings*. DOI `10.1063/1.3180083 <http://dx.doi.org/10.1063/1.3180083>`_

.. [Chareyre2011] \ B. Chareyre, E. Catalano, E. Barthélémy (2011), **Numerical simulation of hydromechanical couplings by combined discrete element method and finite-volumes**. In *International Conference on Flows and Mechanics in Natural Porous Media from Pore to Field Scale - Pore2Field*. `(fulltext) <http://geo.hmg.inpg.fr/~chareyre/pubs/IFPEN-Pore2Field-Chareyre_et_al_Meta.pdf>`__

.. [Chareyre2012b] \ B. Chareyre, L. Scholtès, F. Darve (2012), **The properties of some stress tensors investigated by dem simulations**. In *Euromech Colloquium 539; Mechanics of Unsaturated Porous Media: Effective Stress principle; from micromechanics to thermodynamics*  `(fulltext) <http://www.geo.uu.nl/hydrogeology/Colloquium2012/Bruno%20Chareyre_Euromech.pdf>`__

.. [Chareyre2012c] \ B. Chareyre (2012), **Micro-poromechanics: recent advances in numerical models and perspectives**. In *ICACM symposium 2012, The role of structure on emerging material properties* 

.. [Chen2008a] \ Chen, F., Drumm, E.C., Guiochon, G., Suzuki, K (2008), **Discrete element simulation of 1d upward seepage flow with particle-fluid interaction using coupled open source software**. In *Proceedings of The 12th International Conference of the International Association for Computer Methods and Advances in Geomechanics (IACMAG) Goa, India*.

.. [Chen2009b] \ Chen, F., Drumm, E.C., Guiochon, G. (2009), **3d dem analysis of graded rock fill sinkhole repair: particle size effects on the probability of stability**. In *Transportation Research Board Conference (Washington DC)*.

.. [Dang2008a] \ Dang, H.K., Mohamed, M.A. (2008), **An algorithm to generate a specimen for discrete element simulations with a predefined grain size distribution.**. In *61th Canadian Geotechnical Conference, Edmonton, Alberta*.

.. [Dang2008b] \ Dang, H.K., Mohamed, M.A. (2008), **3d simulation of the trap door problem using the discrete element method.**. In *61th Canadian Geotechnical Conference, Edmonton, Alberta*.

.. [Favier2009b] \ L. Favier, D. Daudon, F. Donzé, J. Mazars (2009), **Validation of a dem granular flow model aimed at forecasting snow avalanche pressure**. In *AIP Conference Proceedings*. DOI `10.1063/1.3180002 <http://dx.doi.org/10.1063/1.3180002>`_ `(fulltext) <http://link.aip.org/link/?APC/1145/617/1>`__

.. [Gillibert2009] \ Gillibert L., Flin F., Rolland du Roscoat S., Chareyre B., Philip A., Lesaffre B., Meyssonier J. (2009), **Curvature-driven grain segmentation: application to snow images from x-ray microtomography**. In *IEEE Computer Society Conference on Computer Vision and Pattern Recognition (Miami, USA)*.

.. [Guo2013] \ Ning Guo, Jidong Zhao (2013), **A hierarchical model for cross-scale simulation of granular media**. In *Powders and Grains 2013: Proceedings of the 6th International Conference on Micromechanics of Granular Media. AIP Conference Proceedings*. DOI `10.1063/1.4812158 <http://dx.doi.org/10.1063/1.4812158>`_ `(fulltext) <https://www.yade-dem.org/publi/APC001222.pdf>`__

.. [Hadda2013] \ Nejib Hadda, François Nicot, Luc Sibille, Farhang Radjai, Antoinette Tordesillas, Félix Darve (2013), **A multiscale description of failure in granular materials**. In *Powders and Grains 2013: Proceedings of the 6th International Conference on Micromechanics of Granular Media. AIP Conference Proceedings*. DOI `10.1063/1.4811999 <http://dx.doi.org/10.1063/1.4811999>`_ `(fulltext) <https://www.yade-dem.org/publi/APC000585.pdf>`__

.. [Harthong2013] \ Barthélémy Harthong, Richard G Wan (2009), **Directional plastic flow and fabric dependencies in granular materials**. In *Powders and Grains 2013: Proceedings of the 6th International Conference on Micromechanics of Granular Media. AIP Conference Proceedings*. DOI `http://dx.doi.org/10.1063/1.4811900 <http://dx.doi.org/http://dx.doi.org/10.1063/1.4811900>`_ `(fulltext) <https://www.yade-dem.org/publi/APC000193.pdf>`__

.. [Hasan2010b] \ A. Hasan, B. Chareyre, J. Kozicki, F. Flin, F. Darve, J. Meyssonnier (2010), **Microtomography-based discrete element modeling to simulate snow microstructure deformation**. In *AGU Fall Meeting Abstracts* 

.. [Hicher2009] \ Hicher P.-Y., Scholtès L., Chareyre B., Nicot F., Darve F. (2008), **On the capillary stress tensor in wet granular materials**. In *Inaugural International Conference of the Engineering Mechanics Institute (EM08) - (Minneapolis, USA)*.

.. [Hicher2011] \ Hicher, P.Y, Scholtès, L., Sibille, L. (2011), **Multiscale modeling of particle removal impact on granular material behavior**. In *Engineering Mechanics Institute, EMI 2011*.

.. [Hilton2013] \ J. E. Hilton, P. W. Cleary, A. Tordesillas (2013), **Unitary stick-slip motion in granular beds**. In *Powders and Grains 2013: Proceedings of the 6th International Conference on Micromechanics of Granular Media. AIP Conference Proceedings*. DOI `10.1063/1.4812063 <http://dx.doi.org/10.1063/1.4812063>`_ `(fulltext) <http://scitation.aip.org/getpdf/servlet/GetPDFServlet?filetype=pdf&id=APCPCS001542000001000843000001&idtype=cvips&doi=10.1063/1.4812063&prog=normal>`__

.. [Kozicki2003a] \ J. Kozicki, J. Tejchman (2003), **Discrete methods to describe the behaviour of quasi-brittle and granular materials**. In *16th Engineering Mechanics Conference, University of Washington, Seattle, CD--ROM*.

.. [Kozicki2003c] \ J. Kozicki, J. Tejchman (2003), **Lattice method to describe the behaviour of quasi-brittle materials**. In *CURE Workshop, Effective use of building materials, Sopot*.

.. [Kozicki2004a] \ J. Kozicki, J. Tejchman (2004), **Study of fracture process in concrete using a discrete lattice model**. In *CURE Workshop, Simulations in Urban Engineering, Gdansk*.

.. [Kozicki2005b] \ J. Kozicki, J. Tejchman (2005), **Simulations of fracture in concrete elements using a discrete lattice model**. In *Proc. Conf. Computer Methods in Mechanics (CMM 2005), Czestochowa, Poland*.

.. [Kozicki2005c] \ J. Kozicki, J. Tejchman (2005), **Simulation of the crack propagation in concrete with a discrete lattice model**. In *Proc. Conf. Analytical Models and New Concepts in Concrete and Masonry Structures (AMCM 2005), Gliwice, Poland*.

.. [Kozicki2006b] \ J. Kozicki, J. Tejchman (2006), **Modelling of fracture process in brittle materials using a lattice model**. In *Computational Modelling of Concrete Structures, EURO-C (eds.: G. Meschke, R. de Borst, H. Mang and N. Bicanic), Taylor anf Francis*.

.. [Kozicki2006c] \ J. Kozicki, J. Tejchman (2006), **Lattice type fracture model for brittle materials**. In *35th Solid Mechanics Conference (SOLMECH 2006), Krakow*.

.. [Kozicki2007c] \ J. Kozicki, J. Tejchman (2007), **Simulations of fracture processes in concrete using a 3d lattice model**. In *Int. Conf. on Computational Fracture and Failure of Materials and Structures (CFRAC 2007), Nantes*. `(fulltext) <https://yade-dem.org/w/images/2/27/Nantes_2007_kozicki.pdf>`__

.. [Kozicki2007d] \ J. Kozicki, J. Tejchman (2007), **Effect of aggregate density on fracture process in concrete using 2d discrete lattice model**. In *Proc. Conf. Computer Methods in Mechanics (CMM 2007), Lodz-Spala*.

.. [Kozicki2007e] \ J. Kozicki, J. Tejchman (2007), **Modelling of a direct shear test in granular bodies with a continuum and a discrete approach**. In *Proc. Conf. Computer Methods in Mechanics (CMM 2007), Lodz-Spala*.

.. [Kozicki2007f] \ J. Kozicki, J. Tejchman (2007), **Investigations of size effect in tensile fracture of concrete using a lattice model**. In *Proc. Conf. Modelling of Heterogeneous Materials with Applications in Construction and Biomedical Engineering (MHM 2007), Prague*.

.. [Kozicki2011] \ J. Kozicki, J. Tejchman (2011), **Numerical simulation of sand behaviour using dem with two different descriptions of grain roughness**. In *II International Conference on Particle-based Methods - Fundamentals and Applications*. `(fulltext) <https://yade-dem.org/w/images/9/96/KozickyTejchmanParticles2011.pdf>`__

.. [Kozicki2013] \ Jan Kozicki, Jacek Tejchman, Danuta Lesniewska (2013), **Study of some micro-structural phenomena in granular shear zones**. In *Powders and Grains 2013: Proceedings of the 6th International Conference on Micromechanics of Granular Media. AIP Conference Proceedings*. DOI `10.1063/1.4811976 <http://dx.doi.org/10.1063/1.4811976>`_ `(fulltext) <https://www.yade-dem.org/publi/APC000495.pdf>`__

.. [Lomine2010a] \ Lominé, F., Scholtès, L., Poullain, P., Sibille, L. (2010), **Soil microstructure changes induced by internal fluid flow: investigations with coupled de/lb methods**. In *Proc. of 3rd Euromediterranean Symposium on Advances in Geomaterials and Structures, AGS'10*.

.. [Lomine2010b] \ Lominé, F., Poullain, P., Sibille, L. (2010), **Modelling of fluid-solid interaction in granular media with coupled lb/de methods: application to solid particle detachment under hydraulic loading**. In *19th Discrete Simulation of Fluid Dynamics, DSFD 2010*.

.. [Lomine2011] \ Lominé, F., Sibille, L., Marot, D. (2011), **A coupled discrete element - lattice botzmann method to investigate internal erosion in soil**. In *Proc. 2nd Int. Symposium on Computational Geomechanics (ComGeo II)*.

.. [Michallet2012] \ H. Michallet, E. Catalano, C. Berni, V. Rameliarison, E. Barthélémy (2012), **Physical and numerical modelling of sand liquefaction in waves interacting with a vertical wall**. In *ICSE6 - 6th International conference on Scour and Erosion* 

.. [Modenese2012] \ C. Modenese, S. Utili, G.T. Houlsby (2012), **Dem modelling of elastic adhesive particles with application to lunar soil**. In *Earth and Space 2012: Engineering, Science, Construction, and Operations in Challenging Environments ¬© 2012 ASCE*. DOI `10.1061/9780784412190.006 <http://dx.doi.org/10.1061/9780784412190.006>`_ `(fulltext) <http://ascelibrary.org/doi/abs/10.1061/9780784412190.006>`__

.. [Modenese2012a] \ Modenese, C, Utili, S, Houlsby, G T (2012), **A study of the influence of surface energy on the mechanical properties of lunar soil using DEM**. In *Discrete Element Modelling of Particulate Media* ( Wu, Chuan-Yu, ed.), Royal Society of Chemistry , DOI `10.1039/9781849735032-00069 <http://dx.doi.org/10.1039/9781849735032-00069>`_ `(fulltext) <http://pubs.rsc.org/en/content/chapter/bk9781849733601-00069/978-1-84973-503-2>`__

.. [Modenese2012b] \ Modenese, C, Utili, S, Houlsby, G T (2012), **A numerical investigation of quasi-static conditions for granular media**. In *Discrete Element Modelling of Particulate Media* ( Wu, Chuan-Yu, ed.), Royal Society of Chemistry , DOI `10.1039/9781849735032-00187 <http://dx.doi.org/10.1039/9781849735032-00187>`_ `(fulltext) <http://pubs.rsc.org/en/content/chapter/bk9781849733601-00187/978-1-84973-503-2>`__

.. [Nicot2010] \ Nicot, F., Sibille, L., Daouadji, A., Hicher, P.Y., Darve, F. (2010), **Multiscale modeling of instability in granular materials**. In *Engineering Mechanics Institute, EMI 2010*.

.. [Nicot2011b] \ Nicot, F., Hadda, N., Bourrier, F., Sibille, L., Darve, F. (2011), **A discrete element analysis of collapse mechanisms in granular materials**. In *Proc. 2nd Int. Symposium on Computational Geomechanics (ComGeo II)*.

.. [Sari2011] \ H. Sari, B. Chareyre, E. Catalano, P. Philippe, E. Vincens (2011), **Investigation of internal erosion processes using a coupled dem-fluid method**. In *II International Conference on Particle-based Methods - Fundamentals and Applications*. `(fulltext) <http://geo.hmg.inpg.fr/~chareyre/pubs/SariChareyreCatalanoPhilippeVincens_Particles2011.pdf>`__

.. [Scholtes2007a] \ L. Scholtès, B. Chareyre, F. Nicot, F. Darve (2007), **Micromechanical modelling of unsaturated granular media**. In *Proceedings ECCOMAS-MHM07, Prague*.

.. [Scholtes2008a] \ L. Scholtès, B. Chareyre, F. Nicot, F. Darve (2008), **Capillary effects modelling in unsaturated granular materials**. In *8th World Congress on Computational Mechanics - 5th European Congress on Computational Methods in Applied Sciences and Engineering, Venice*.

.. [Scholtes2008b] \ L. Scholtès, P.-Y. Hicher, F.Nicot, B. Chareyre, F. Darve (2008), **On the capillary stress tensor in unsaturated granular materials**. In *EM08: Inaugural International Conference of the Engineering Mechanics Institute, Minneapolis*.

.. [Scholtes2009e] \ Scholtes L, Chareyre B, Darve F (2009), **Micromechanics of partialy saturated granular material**. In *Int. Conf. on Particle Based Methods, ECCOMAS-Particles*.

.. [Scholtes2011b] \ L. Scholtès, F. Donzé (2011), **Progressive failure mechanisms in jointed rock: insight from 3d dem modelling**. In *II International Conference on Particle-based Methods - Fundamentals and Applications*. `(fulltext) <https://yade-dem.org/w/images/3/32/ScholtesDonzeParticles2011.pdf>`__

.. [Scholtes2011c] \ Scholtès, L., Hicher, P.Y., Sibille, L. (2011), **A micromechanical approach to describe internal erosion effects in soils**. In *Proc. of Geomechanics and Geotechnics: from micro to macro, IS-Shanghai 2011*.

.. [Shiu2007a] \ W. Shiu, F.V. Donze, L. Daudeville (2007), **Discrete element modelling of missile impacts on a reinforced concrete target**. In *Int. Conf. on Computational Fracture and Failure of Materials and Structures (CFRAC 2007), Nantes*.

.. [Sibille2009] \ Sibille, L., Scholtès, L. (2009), **Effects of internal erosion on mechanical behaviour of soils: a dem approach**. In *Proc. of International Conference on Particle-Based Methods, Particles 2009*.

.. [Smilauer2007a] \ V. Šmilauer (2007), **Discrete and hybrid models: applications to concrete damage**. In *Unpublished*. `(fulltext) <https://yade-dem.org/w/images/c/c8/Smilauer-discrete_and_hybrid_models_for_concrete-2007.pdf>`__

.. [Smilauer2008] \ Václav Šmilauer (2008), **Commanding c++ with python**. In *ALERT Doctoral school talk*. `(fulltext) <https://yade-dem.org/w/images/4/40/Yade-python-aussois-2008.pdf>`__

.. [Smilauer2010a] \ Václav Šmilauer (2010), **Yade: past, present, future**. In *Internal seminary in Laboratoire 3S-R, Grenoble*. `(fulltext) <https://yade-dem.org/w/images/5/59/Eudoxos2010-yade-past-present-future.pdf>`__ (`LaTeX sources <http://bazaar.launchpad.net/~eudoxos/yade/pres-grenoble2010/files>`_)

.. [Stransky2010] \ Jan Stránský, Milan Jirásek, Václav Šmilauer (2010), **Macroscopic elastic properties of particle models**. In *Proceedings of the International Conference on Modelling and Simulation 2010, Prague*. `(fulltext) <https://yade-dem.org/w/images/6/64/Stransky2010-Macroscopic-elastic-properties-of-particle-models.pdf>`__

.. [Stransky2011] \ J. Stransky, M. Jirasek (2011), **Calibration of particle-based models using cells with periodic boundary conditions**. In *II International Conference on Particle-based Methods - Fundamentals and Applications*. `(fulltext) <http://yade-dem.org/publi/Stransky2011Barcelona_meta.pdf>`__

.. [Thoeni2011] \ K. Thoeni, C. Lambert, A. Giacomini, S.W. Sloan (2011), **Discrete modelling of a rockfall protective system**. In *Particles 2011: Fundamentals and Applications*. `(fulltext) <https://yade-dem.org/w/images/7/7d/ThoenietAlParticles2011.pdf>`__

.. [Tran2012b] \ Tran, V.D.H, Meguid, M.A, Chouinard, L.E (2012), **A discrete element study of the earth pressure distribution on cylindrical shafts**. In *Tunnelling Association of Canada (TAC) Conference 2012, Montreal* 

Master and PhD theses
-----------------------
.. [Catalano2008a] \ E. Catalano (2008), **Inﬁltration effects on a partially saturated slope - an application of the discrete element method and its implementation in the open-source software yade**. Master thesis at *UJF-Grenoble*. `(fulltext) <https://yade-dem.org/w/images/a/af/SlopeStability.pdf>`__

.. [Chen2009a] \ Chen, F. (2009), **Coupled flow discrete element method application in granular porous media using open source codes**. PhD thesis at *University of Tennessee, Knoxville*. `(fulltext) <http://trace.tennessee.edu/cgi/viewcontent.cgi?article=1051&context=utk_graddiss>`__

.. [Chen2011b] \ Chen, J. (2011), **Discrete element method (dem) analyses for hot-mix asphalt (hma) mixture compaction**. PhD thesis at *University of Tennessee, Knoxville*. `(fulltext) <http://trace.tennessee.edu/cgi/viewcontent.cgi?article=2102&context=utk_graddiss>`__

.. [Duriez2009a] \ J. Duriez (2009), **Stabilité des massifs rocheux : une approche mécanique**. PhD thesis at *Institut polytechnique de Grenoble*. `(fulltext) <http://tel.archives-ouvertes.fr/tel-00462072/fr/>`__

.. [Favier2009c] \ Favier, L. (2009), **Approche numérique par éléments discrets 3d de la sollicitation d'un écoulement granulaire sur un obstacle**. *Doctoral Dissertations*.

.. [Jerier2009b] \ Jerier, J.F. (2009), **Modélisation de la compression haute densité des poudres métalliques ductiles par la méthode des éléments discrets (in french)**. PhD thesis at *Université Grenoble I – Joseph Fourier*. `(fulltext) <http://tel.archives-ouvertes.fr/tel-00443670/fr/>`__

.. [Kozicki2007b] \ J. Kozicki (2007), **Application of discrete models to describe the fracture process in brittle materials**. PhD thesis at *Gdansk University of Technology*. `(fulltext) <http://janek.kozicki.pl/phdthesis/kozicki_2007_PhD.pdf>`__

.. [Marzougui2011] \ Marzougui, D. (2011), **Hydromechanical modeling of the transport and deformation in bed load sediment with discrete elements and finite volume**. Master thesis at *Ecole Nationale d'Ingénieur de Tunis*. `(fulltext) <http://yade-dem.org/publi/MasterMarzougui_meta.pdf>`__

.. [Scholtes2009d] \ Luc Scholtès (2009), **modélisation micromécanique des milieux granulaires partiellement saturés**. PhD thesis at *Institut National Polytechnique de Grenoble*. `(fulltext) <http://tel.archives-ouvertes.fr/tel-00363961/en/>`__

.. [Smilauer2010b] \ Václav Šmilauer (2010), **Cohesive particle model using the discrete element method on the yade platform**. PhD thesis at *Czech Technical University in Prague, Faculty of Civil Engineering & Université Grenoble I -- Joseph Fourier, École doctorale I-MEP2*. `(fulltext) <http://beta.arcig.cz/~eudoxos/smilauer2010-phd-thesis.pdf>`__ (`LaTeX sources <http://bazaar.launchpad.net/~eudoxos/+junk/thesis/files>`__)

.. [Smilauer2010c] \ Václav Šmilauer (2010), **Doctoral thesis statement**. *(PhD thesis summary)*. `(fulltext) <http://beta.arcig.cz/~eudoxos/smilauer2010-phd-thesis-statement.pdf>`__ (`LaTeX sources <http://bazaar.launchpad.net/~eudoxos/+junk/thesis/files>`__)

.. [Tran2011b] \ Van Tieng TRAN (2011), **Structures en béton soumises à des chargements mécaniques extrêmes: modélisation de la réponse locale par la méthode des éléments discrets (in french)**. PhD thesis at *Université Grenoble I – Joseph Fourier*. `(fulltext) <https://yade-dem.org/w/images/2/27/VanTranTiengThesis.pdf>`__



