# encoding: utf-8
# 2011 © Bruno Chareyre <bruno.chareyre@hmg.inpg.fr>
# A dummy test, just to give an example, and detect possible path problems
from yade import pack,utils,export,plot
import math,os,sys
print 'checkTest mechanism'

