#include<yade/core/Shape.hpp>
Shape::~Shape(){}
