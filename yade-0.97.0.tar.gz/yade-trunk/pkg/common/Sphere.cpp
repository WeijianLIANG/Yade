#include "Sphere.hpp"
Sphere::~Sphere(){}
YADE_PLUGIN((Sphere));
