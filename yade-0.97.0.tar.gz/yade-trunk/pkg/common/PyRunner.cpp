#include<yade/pkg/common/PyRunner.hpp>
YADE_PLUGIN((PyRunner));
