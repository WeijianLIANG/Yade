#include<yade/pkg/common/PeriodicEngines.hpp>
YADE_PLUGIN((PeriodicEngine));
PeriodicEngine::~PeriodicEngine(){};
