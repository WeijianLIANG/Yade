// 2009 © Václav Šmilauer <eudoxos@arcig.cz>
#include<yade/pkg/common/ElastMat.hpp>
YADE_PLUGIN((ElastMat)(FrictMat));
ElastMat::~ElastMat(){}
FrictMat::~FrictMat(){}
