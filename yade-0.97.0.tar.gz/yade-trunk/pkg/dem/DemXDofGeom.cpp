#include"DemXDofGeom.hpp"
YADE_PLUGIN((GenericSpheresContact)(Dem3DofGeom));
Real Dem3DofGeom::displacementN(){throw;}
Dem3DofGeom::~Dem3DofGeom(){}
GenericSpheresContact::~GenericSpheresContact(){}
