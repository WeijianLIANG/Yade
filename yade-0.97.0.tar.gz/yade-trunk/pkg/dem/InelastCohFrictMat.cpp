#include "InelastCohFrictMat.hpp"

InelastCohFrictMat::~InelastCohFrictMat()
{
}

YADE_PLUGIN((InelastCohFrictMat));