
#include "NormalInelasticMat.hpp"


NormalInelasticMat::~NormalInelasticMat()
{
}

YADE_PLUGIN((NormalInelasticMat));



