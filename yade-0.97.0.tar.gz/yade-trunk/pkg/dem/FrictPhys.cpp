#include "FrictPhys.hpp"
FrictPhys::~FrictPhys(){}
ViscoFrictPhys::~ViscoFrictPhys(){}
YADE_PLUGIN((FrictPhys)(ViscoFrictPhys));
