#include <yade/pkg/dem/CapillaryPhys.hpp>

CapillaryPhys::~CapillaryPhys()
{
}

YADE_PLUGIN((CapillaryPhys));

