/*************************************************************************
*  Copyright (C) 2012 by Ignacio Olmedo nolmedo.manich@gmail.com         *
*  Copyright (C) 2012 by François Kneib   francois.kneib@gmail.com       *
*  This program is free software; it is licensed under the terms of the  *
*  GNU General Public License v2 or later. See file LICENSE for details. *
*************************************************************************/


#include "InelastCohFrictPhys.hpp"
InelastCohFrictPhys::~InelastCohFrictPhys()
{
}
YADE_PLUGIN((InelastCohFrictPhys));