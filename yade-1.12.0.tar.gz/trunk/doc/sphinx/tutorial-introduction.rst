
Introduction
=============

Slides `Yade: past, present and future <http://beta.arcig.cz/~eudoxos/dresden2011/pres-3s.pdf>`__ (updated version)


.. todo:: Put link to the `Yade: past, present and future <https://yade-dem.org/w/images/5/59/Eudoxos2010-yade-past-present-future.pdf>`__, or adapt it to give more general intro to particle models.

.. todo:: Think about what is the scope of the introduction.
