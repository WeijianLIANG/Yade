"Module storing parametr values, used by :yref:`yade.utils.saveVars`, :yref:`yade.utils.saveVars`, :yref:`yade.utils.readParamsFromTable`."
# initially empty
__all__=[]